package vn.edu.eaut.lab5.util;
import javax.swing.*;
public class MessageUtil {
    public static void info(java.awt.Component c,String s){JOptionPane.showMessageDialog(c,s,"Thong bao",JOptionPane.INFORMATION_MESSAGE);}
    public static void error(java.awt.Component c,String s){JOptionPane.showMessageDialog(c,s,"Loi",JOptionPane.ERROR_MESSAGE);}
}
