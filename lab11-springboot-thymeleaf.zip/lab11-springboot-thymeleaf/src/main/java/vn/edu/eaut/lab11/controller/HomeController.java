package vn.edu.eaut.lab11.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @GetMapping("/")
    public String index(Model model) {

        model.addAttribute(
                "title",
                "Hệ thống quản lý sinh viên"
        );

        model.addAttribute(
                "message",
                "Chào mừng bạn đến với ứng dụng Spring Boot"
        );

        return "index";
    }

    @GetMapping("/about")
    public String about(Model model) {

        model.addAttribute(
                "course",
                "Công nghệ Java"
        );

        model.addAttribute(
                "chapter",
                "Chương 4 - Phát triển ứng dụng với Spring Framework"
        );

        return "about";
    }

    @GetMapping("/contact")
    public String contact(Model model) {

        model.addAttribute(
                "department",
                "Khoa Công nghệ Thông tin"
        );

        model.addAttribute(
                "email",
                "cntt@eaut.edu.vn"
        );

        model.addAttribute(
                "phone",
                "024 6262 7797"
        );

        return "contact";
    }
}