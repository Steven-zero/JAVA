package vn.edu.eaut.lab5.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class HoaDon {
    private int maHd, maKh;
    private LocalDate ngayLap;
    private BigDecimal tongTien;

    public HoaDon() {}
    public HoaDon(int maHd, LocalDate ngayLap, int maKh, BigDecimal tongTien) {
        this.maHd=maHd; this.ngayLap=ngayLap; this.maKh=maKh; this.tongTien=tongTien;
    }
    public int getMaHd(){return maHd;} public void setMaHd(int v){maHd=v;}
    public LocalDate getNgayLap(){return ngayLap;} public void setNgayLap(LocalDate v){ngayLap=v;}
    public int getMaKh(){return maKh;} public void setMaKh(int v){maKh=v;}
    public BigDecimal getTongTien(){return tongTien;} public void setTongTien(BigDecimal v){tongTien=v;}
}
