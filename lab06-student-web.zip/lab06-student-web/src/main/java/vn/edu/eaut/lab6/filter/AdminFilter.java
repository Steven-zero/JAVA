package vn.edu.eaut.lab6.filter;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebFilter(urlPatterns = {"/student-form.jsp", "/students/edit", "/students/delete"})
public class AdminFilter implements Filter {
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;
        HttpSession session = req.getSession(false);
        if (session != null && "ADMIN".equals(session.getAttribute("role"))) {
            chain.doFilter(request, response);
        } else {
            resp.sendRedirect(req.getContextPath() + "/403.jsp");
        }
    }
}
