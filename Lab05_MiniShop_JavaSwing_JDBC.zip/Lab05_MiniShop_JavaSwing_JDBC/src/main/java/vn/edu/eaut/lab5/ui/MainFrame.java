package vn.edu.eaut.lab5.ui;

import javax.swing.*;import java.awt.*;

public class MainFrame extends JFrame {
    public MainFrame(){setTitle("MiniShop - Java Swing JDBC");setSize(950,600);setLocationRelativeTo(null);setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JTabbedPane tabs=new JTabbedPane();tabs.addTab("Sản phẩm",new SanPhamPanel());tabs.addTab("Khách hàng",new KhachHangPanel());tabs.addTab("Hóa đơn",new HoaDonPanel());tabs.addTab("Thống kê",new ThongKePanel());add(tabs,BorderLayout.CENTER);}
}
