package vn.edu.eaut.lab5.ui;

import vn.edu.eaut.lab5.bus.*;import vn.edu.eaut.lab5.model.*;
import vn.edu.eaut.lab5.util.MessageUtil;
import javax.swing.*;import javax.swing.table.DefaultTableModel;import java.awt.*;import java.math.BigDecimal;import java.util.ArrayList;
import java.util.List;

public class HoaDonPanel extends JPanel {
    JComboBox<KhachHang> kh=new JComboBox<>();JComboBox<SanPham> sp=new JComboBox<>();JTextField sl=new JTextField("1");
    DefaultTableModel m=new DefaultTableModel(new Object[]{"Mã SP","Tên","SL","Đơn giá","Thành tiền"},0);JTable table=new JTable(m);
    JLabel total=new JLabel("Tổng: 0 VND");List<ChiTietHoaDon> list=new ArrayList<>();KhachHangBUS kb=new KhachHangBUS();SanPhamBUS sb=new SanPhamBUS();HoaDonBUS hb=new HoaDonBUS();
    public HoaDonPanel(){setLayout(new BorderLayout(8,8));JPanel top=new JPanel(new GridLayout(2,4,5,5));
        top.add(new JLabel("Khách hàng"));top.add(new JLabel("Sản phẩm"));top.add(new JLabel("Số lượng"));top.add(new JLabel(""));
        top.add(kh);top.add(sp);top.add(sl);JButton add=new JButton("Thêm dòng");top.add(add);add(top,BorderLayout.NORTH);add(new JScrollPane(table),BorderLayout.CENTER);
        JPanel bottom=new JPanel();JButton save=new JButton("Lưu hóa đơn"),clear=new JButton("Xóa dòng");bottom.add(total);bottom.add(clear);bottom.add(save);add(bottom,BorderLayout.SOUTH);
        load();add.addActionListener(e->addLine());clear.addActionListener(e->{int r=table.getSelectedRow();if(r>=0){list.remove(r);m.removeRow(r);calc();}});
        save.addActionListener(e->save());
    }
    void load(){try{for(KhachHang k:kb.findAll())kh.addItem(k);for(SanPham s:sb.findAll())sp.addItem(s);}catch(Exception e){MessageUtil.error(this,e.getMessage());}}
    void addLine(){try{SanPham s=(SanPham)sp.getSelectedItem();int n=Integer.parseInt(sl.getText());if(s==null||n<=0)throw new IllegalArgumentException("So luong khong hop le");if(n>s.getSoLuong())throw new IllegalArgumentException("So luong vuot ton kho");ChiTietHoaDon x=new ChiTietHoaDon(s.getMaSp(),s.getTenSp(),n,s.getDonGia());list.add(x);m.addRow(new Object[]{x.getMaSp(),x.getTenSp(),n,x.getDonGia(),x.getThanhTien()});calc();}catch(Exception e){MessageUtil.error(this,e.getMessage());}}
    void calc(){BigDecimal t=BigDecimal.ZERO;for(ChiTietHoaDon x:list)t=t.add(x.getThanhTien());total.setText("Tổng: "+t+" VND");}
    void save(){try{KhachHang k=(KhachHang)kh.getSelectedItem();int id=hb.save(k.getMaKh(),list);MessageUtil.info(this,"Đã lưu hóa đơn #"+id);list.clear();m.setRowCount(0);calc();}catch(Exception e){MessageUtil.error(this,e.getMessage());}}
}
