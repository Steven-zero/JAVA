package vn.edu.eaut.lab5.dal;

import vn.edu.eaut.lab5.config.DBHelper;
import vn.edu.eaut.lab5.model.ChiTietHoaDon;
import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDate;
import java.util.List;

public class HoaDonDAL {
    public int insertHoaDon(int maKh,List<ChiTietHoaDon> list)throws SQLException{
        if(list==null||list.isEmpty())throw new IllegalArgumentException("Hoa don phai co san pham");
        String h="INSERT INTO hoa_don(ngay_lap,ma_kh,tong_tien) VALUES(?,?,?)";
        String d="INSERT INTO chi_tiet_hoa_don(ma_hd,ma_sp,so_luong,don_gia,thanh_tien) VALUES(?,?,?,?,?)";
        try(Connection c=DBHelper.getConnection()){
            c.setAutoCommit(false);
            try{
                BigDecimal total=BigDecimal.ZERO;
                for(ChiTietHoaDon x:list) total=total.add(x.getThanhTien());
                int id;
                try(PreparedStatement p=c.prepareStatement(h,Statement.RETURN_GENERATED_KEYS)){
                    p.setDate(1,Date.valueOf(LocalDate.now()));p.setInt(2,maKh);p.setBigDecimal(3,total);p.executeUpdate();
                    try(ResultSet r=p.getGeneratedKeys()){if(!r.next())throw new SQLException("Khong lay duoc ma hoa don");id=r.getInt(1);}
                }
                try(PreparedStatement p=c.prepareStatement(d)){
                    for(ChiTietHoaDon x:list){
                        p.setInt(1,id);p.setInt(2,x.getMaSp());p.setInt(3,x.getSoLuong());
                        p.setBigDecimal(4,x.getDonGia());p.setBigDecimal(5,x.getThanhTien());p.addBatch();
                    }
                    p.executeBatch();
                }
                c.commit();return id;
            }catch(SQLException e){c.rollback();throw e;}finally{c.setAutoCommit(true);}
        }
    }
}
