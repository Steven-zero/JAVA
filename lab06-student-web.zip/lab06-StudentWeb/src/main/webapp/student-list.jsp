<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<html><head><title>Danh sách sinh viên</title>
<style>
body{font-family:Arial;margin:30px}table{border-collapse:collapse;width:100%;margin-top:20px}
th,td{border:1px solid #aaa;padding:9px}th{background:#eee}
a{margin-right:8px}.top{display:flex;gap:10px;align-items:center}
input{padding:8px;width:300px}button{padding:8px 15px}
</style></head>
<body>
<h2>Danh sách sinh viên</h2>
<p>Xin chào: <b>${sessionScope.username}</b> (${sessionScope.role})</p>

<form class="top" action="${pageContext.request.contextPath}/students" method="get">
<input type="text" name="keyword" value="${keyword}" placeholder="Tìm theo họ tên...">
<button type="submit">Tìm kiếm</button>
<a href="${pageContext.request.contextPath}/students">Hiển thị tất cả</a>
</form>

<c:if test="${sessionScope.role == 'ADMIN'}">
<p><a href="${pageContext.request.contextPath}/student-form.jsp">+ Thêm sinh viên</a></p>
</c:if>

<c:choose>
<c:when test="${empty students}">
<p>Không tìm thấy sinh viên phù hợp.</p>
</c:when>
<c:otherwise>
<table>
<tr><th>Mã SV</th><th>Họ tên</th><th>Lớp</th><th>Email</th><th>Thao tác</th></tr>
<c:forEach var="sv" items="${students}">
<tr>
<td>${sv.id}</td><td>${sv.name}</td><td>${sv.className}</td><td>${sv.email}</td>
<td>
<c:if test="${sessionScope.role == 'ADMIN'}">
<a href="${pageContext.request.contextPath}/students?action=edit&id=${sv.id}">Sửa</a>
<a href="${pageContext.request.contextPath}/students?action=delete&id=${sv.id}"
   onclick="return confirm('Bạn có chắc muốn xóa?')">Xóa</a>
</c:if>
<c:if test="${sessionScope.role == 'USER'}">Chỉ xem</c:if>
</td>
</tr>
</c:forEach>
</table>
</c:otherwise>
</c:choose>

<p><a href="${pageContext.request.contextPath}/welcome.jsp">Dashboard</a>
<a href="${pageContext.request.contextPath}/logout">Đăng xuất</a></p>
</body></html>
