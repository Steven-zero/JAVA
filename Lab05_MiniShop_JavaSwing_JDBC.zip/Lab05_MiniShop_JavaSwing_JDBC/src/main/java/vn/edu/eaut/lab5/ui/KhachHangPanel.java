package vn.edu.eaut.lab5.ui;

import vn.edu.eaut.lab5.bus.KhachHangBUS;
import vn.edu.eaut.lab5.model.KhachHang;
import vn.edu.eaut.lab5.util.MessageUtil;
import javax.swing.*;import javax.swing.table.DefaultTableModel;import java.awt.*;

public class KhachHangPanel extends JPanel {
    JTextField id=new JTextField(),ten=new JTextField(),sdt=new JTextField(),dc=new JTextField(),search=new JTextField();
    DefaultTableModel m=new DefaultTableModel(new Object[]{"Mã","Tên","SĐT","Địa chỉ"},0); JTable t=new JTable(m); KhachHangBUS bus=new KhachHangBUS();
    public KhachHangPanel(){setLayout(new BorderLayout(8,8)); JPanel f=new JPanel(new GridLayout(2,5,5,5));
        for(String x:new String[]{"Mã","Tên","SĐT","Địa chỉ","Tìm kiếm"})f.add(new JLabel(x));
        f.add(id);f.add(ten);f.add(sdt);f.add(dc);f.add(search);id.setEditable(false);add(f,BorderLayout.NORTH);add(new JScrollPane(t),BorderLayout.CENTER);
        JPanel p=new JPanel();JButton a=new JButton("Thêm"),e=new JButton("Sửa"),d=new JButton("Xóa"),c=new JButton("Làm mới"),q=new JButton("Tìm");
        for(JButton b:new JButton[]{a,e,d,c,q})p.add(b);add(p,BorderLayout.SOUTH);
        t.getSelectionModel().addListSelectionListener(x->{int r=t.getSelectedRow();if(r>=0){id.setText(m.getValueAt(r,0).toString());ten.setText(m.getValueAt(r,1).toString());sdt.setText(m.getValueAt(r,2).toString());dc.setText(m.getValueAt(r,3).toString());}});
        a.addActionListener(x->save(0));e.addActionListener(x->save(Integer.parseInt(id.getText().isEmpty()?"0":id.getText())));
        d.addActionListener(x->{try{bus.delete(Integer.parseInt(id.getText()));load();clear();}catch(Exception z){MessageUtil.error(this,z.getMessage());}});
        c.addActionListener(x->clear());q.addActionListener(x->loadSearch());load();
    }
    void save(int i){try{if(bus.save(new KhachHang(i,ten.getText(),sdt.getText(),dc.getText()))){MessageUtil.info(this,i==0?"Đã thêm":"Đã sửa");load();clear();}}catch(Exception e){MessageUtil.error(this,e.getMessage());}}
    void load(){try{m.setRowCount(0);for(KhachHang k:bus.findAll())m.addRow(new Object[]{k.getMaKh(),k.getTenKh(),k.getSdt(),k.getDiaChi()});}catch(Exception e){MessageUtil.error(this,e.getMessage());}}
    void loadSearch(){try{m.setRowCount(0);for(KhachHang k:bus.search(search.getText()))m.addRow(new Object[]{k.getMaKh(),k.getTenKh(),k.getSdt(),k.getDiaChi()});}catch(Exception e){MessageUtil.error(this,e.getMessage());}}
    void clear(){id.setText("");ten.setText("");sdt.setText("");dc.setText("");}
}
