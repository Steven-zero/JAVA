package vn.edu.eaut.lab8.bean;

import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;
import vn.edu.eaut.lab8.model.Product;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Named("productBean")
@SessionScoped
public class ProductBean implements Serializable {
    private Product product = new Product();
    private final List<Product> products = new ArrayList<>();

    public void save() {
        products.add(product);
        FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Thành công", "Đã thêm sản phẩm."));
        product = new Product();
    }
    public Product getProduct(){return product;} public void setProduct(Product p){product=p;}
    public List<Product> getProducts(){return products;}
}
