package vn.edu.eaut.lab11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab11SpringbootThymeleafApplication {

    public static void main(String[] args) {
        SpringApplication.run(Lab11SpringbootThymeleafApplication.class, args);
    }

}
