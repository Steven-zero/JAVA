<%@ page contentType="text/html;charset=UTF-8" %>
<html><head><title>Lab 6</title></head>
<body>
<h1>Lab 6 - Quản lý sinh viên</h1>
<p><a href="${pageContext.request.contextPath}/hello">Bài 1 - Hello Servlet</a></p>
<p><a href="${pageContext.request.contextPath}/login.jsp">Đăng nhập hệ thống</a></p>
</body></html>
