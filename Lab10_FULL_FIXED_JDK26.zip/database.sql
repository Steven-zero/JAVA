CREATE DATABASE IF NOT EXISTS lab10 CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE lab10;
DROP TABLE IF EXISTS login_logs; DROP TABLE IF EXISTS students; DROP TABLE IF EXISTS books; DROP TABLE IF EXISTS products; DROP TABLE IF EXISTS users;
CREATE TABLE users(id INT AUTO_INCREMENT PRIMARY KEY,email VARCHAR(100) NOT NULL UNIQUE,password VARCHAR(255) NOT NULL,full_name VARCHAR(100) NOT NULL,role VARCHAR(20) NOT NULL,active BOOLEAN NOT NULL DEFAULT TRUE);
CREATE TABLE students(id INT AUTO_INCREMENT PRIMARY KEY,code VARCHAR(30) NOT NULL UNIQUE,full_name VARCHAR(100) NOT NULL,email VARCHAR(100) NOT NULL,major VARCHAR(100));
CREATE TABLE books(id INT AUTO_INCREMENT PRIMARY KEY,title VARCHAR(150) NOT NULL,author VARCHAR(100) NOT NULL,quantity INT NOT NULL,price DOUBLE NOT NULL);
CREATE TABLE products(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(120) NOT NULL,category VARCHAR(80) NOT NULL,quantity INT NOT NULL,price DOUBLE NOT NULL);
CREATE TABLE login_logs(id BIGINT AUTO_INCREMENT PRIMARY KEY,email VARCHAR(100) NOT NULL,action VARCHAR(50) NOT NULL,ip_address VARCHAR(50),created_at DATETIME NOT NULL);
INSERT INTO users(email,password,full_name,role,active) VALUES
('admin@eaut.edu.vn','123456','Quản trị viên','ADMIN',1),
('staff@eaut.edu.vn','123456','Nhân viên','STAFF',1),
('user@eaut.edu.vn','123456','Người dùng','USER',1);
INSERT INTO students(code,full_name,email,major) VALUES ('SV001','Nguyễn Văn An','an@example.com','Công nghệ thông tin'),('SV002','Trần Thị Bình','binh@example.com','Kỹ thuật phần mềm');
INSERT INTO books(title,author,quantity,price) VALUES ('Lập trình Java','Nguyễn Văn A',10,120000),('Cơ sở dữ liệu','Trần Văn B',8,95000);
INSERT INTO products(name,category,quantity,price) VALUES ('Laptop','Thiết bị',5,15000000),('Chuột không dây','Phụ kiện',20,250000);