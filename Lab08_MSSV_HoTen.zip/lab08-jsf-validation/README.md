# Lab 8 - Jakarta Faces / JSF

## Công nghệ
- JDK 17
- Maven
- Tomcat 10.x
- Jakarta Faces 4.0.7
- Weld CDI
- Hibernate Validator

## Chức năng
1. Trang chủ JSF
2. CRUD sinh viên trên bộ nhớ: thêm, sửa, xóa
3. Validation: mã SV, họ tên, email, lớp
4. FacesMessage và h:messages/h:message
5. h:dataTable
6. Tìm kiếm sinh viên theo mã, họ tên, lớp
7. h:selectOneMenu chọn lớp
8. Form sách
9. Form sản phẩm
10. Form đăng nhập
11. Layout Facelets mẫu

## Chạy
- Mở project bằng IntelliJ/Eclipse/NetBeans.
- Maven Reload/Build.
- Cấu hình Tomcat 10.x.
- Deploy WAR `lab08-jsf-validation.war`.
- Truy cập `http://localhost:8080/lab08-jsf-validation/`.

Dữ liệu hiện lưu trong bộ nhớ, không dùng JPA/Database theo đúng phạm vi Lab 8.
