package vn.edu.eaut.lab3;

import javax.swing.*;
import java.awt.*;

/**
 * Bài 7 - Máy tính mini: cộng, trừ, nhân, chia, có lịch sử phép tính.
 */
public class Bai07MayTinhMini extends JFrame {

    private final JTextField txtA = new JTextField();
    private final JTextField txtB = new JTextField();
    private final JTextField txtResult = new JTextField();
    private final JTextArea txtHistory = new JTextArea(10, 25);

    public Bai07MayTinhMini() {
        setTitle("Bài 7 - Máy tính mini");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Panel nhập liệu
        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 8, 8));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        inputPanel.add(new JLabel("Số thứ nhất:"));
        inputPanel.add(txtA);
        inputPanel.add(new JLabel("Số thứ hai:"));
        inputPanel.add(txtB);
        inputPanel.add(new JLabel("Kết quả:"));
        txtResult.setEditable(false);
        inputPanel.add(txtResult);

        // Panel các nút phép toán
        JPanel btnPanel = new JPanel(new GridLayout(1, 5, 5, 5));
        JButton btnCong = new JButton("+");
        JButton btnTru = new JButton("-");
        JButton btnNhan = new JButton("*");
        JButton btnChia = new JButton("/");
        JButton btnClear = new JButton("Clear");
        btnPanel.add(btnCong);
        btnPanel.add(btnTru);
        btnPanel.add(btnNhan);
        btnPanel.add(btnChia);
        btnPanel.add(btnClear);

        btnCong.addActionListener(e -> tinhToan('+'));
        btnTru.addActionListener(e -> tinhToan('-'));
        btnNhan.addActionListener(e -> tinhToan('*'));
        btnChia.addActionListener(e -> tinhToan('/'));
        btnClear.addActionListener(e -> lamMoi());

        // Lịch sử
        txtHistory.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(txtHistory);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Lịch sử phép tính"));

        JPanel topPanel = new JPanel(new BorderLayout(5, 5));
        topPanel.add(inputPanel, BorderLayout.NORTH);
        topPanel.add(btnPanel, BorderLayout.CENTER);

        add(topPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        setSize(420, 420);
        setLocationRelativeTo(null);
    }

    private void tinhToan(char phepToan) {
        double a, b;
        try {
            a = Double.parseDouble(txtA.getText().trim());
            b = Double.parseDouble(txtB.getText().trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập hai số hợp lệ!",
                    "Lỗi nhập liệu", JOptionPane.ERROR_MESSAGE);
            return;
        }

        double ketQua;
        switch (phepToan) {
            case '+':
                ketQua = a + b;
                break;
            case '-':
                ketQua = a - b;
                break;
            case '*':
                ketQua = a * b;
                break;
            case '/':
                if (b == 0) {
                    JOptionPane.showMessageDialog(this, "Không thể chia cho 0!",
                            "Lỗi phép chia", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                ketQua = a / b;
                break;
            default:
                return;
        }

        String bieuThuc = String.format("%s %s %s = %s",
                formatSo(a), phepToan, formatSo(b), formatSo(ketQua));
        txtResult.setText(formatSo(ketQua));
        txtHistory.append(bieuThuc + "\n");
    }

    private String formatSo(double x) {
        if (x == Math.floor(x) && !Double.isInfinite(x)) {
            return String.valueOf((long) x);
        }
        return String.valueOf(x);
    }

    private void lamMoi() {
        txtA.setText("");
        txtB.setText("");
        txtResult.setText("");
        txtA.requestFocus();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Bai07MayTinhMini().setVisible(true));
    }
}
