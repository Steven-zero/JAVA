<%@ page contentType="text/html;charset=UTF-8" %>
<html><head><title>Đăng nhập</title>
<style>
body{font-family:Arial;background:#f4f6f8}.box{width:380px;margin:80px auto;background:white;padding:30px;border-radius:10px;box-shadow:0 2px 12px #bbb}
input{width:100%;padding:10px;margin:8px 0 16px;box-sizing:border-box}button{padding:10px 20px}
.error{color:red}.hint{color:#666}
</style></head>
<body>
<div class="box">
<h2>Đăng nhập hệ thống</h2>
<form action="${pageContext.request.contextPath}/login" method="post">
<label>Tên đăng nhập:</label>
<input type="text" name="username" required>
<label>Mật khẩu:</label>
<input type="password" name="password" required>
<button type="submit">Đăng nhập</button>
</form>
<p class="error">${error}</p>
<p class="hint">Admin: admin / 123456</p>
<p class="hint">User: user / 123456</p>
</div>
</body></html>
