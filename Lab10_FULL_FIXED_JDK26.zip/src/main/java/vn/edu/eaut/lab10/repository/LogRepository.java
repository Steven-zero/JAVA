package vn.edu.eaut.lab10.repository;
import jakarta.persistence.*; import vn.edu.eaut.lab10.config.JPAUtil; import vn.edu.eaut.lab10.model.LoginLog; import java.util.*;
public class LogRepository {
 public void save(LoginLog x){EntityManager em=JPAUtil.getEntityManagerFactory().createEntityManager();EntityTransaction tx=em.getTransaction();try{tx.begin();em.persist(x);tx.commit();}finally{em.close();}}
 public List<LoginLog> findAll(){EntityManager em=JPAUtil.getEntityManagerFactory().createEntityManager();try{return em.createQuery("from LoginLog order by createdAt desc",LoginLog.class).getResultList();}finally{em.close();}}
}