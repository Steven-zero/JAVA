package vn.edu.eaut.lab5.bus;

import vn.edu.eaut.lab5.dal.ThongKeDAL;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;

public class ThongKeBUS {
    private final ThongKeDAL dal=new ThongKeDAL();
    public BigDecimal tinhDoanhThu(LocalDate f,LocalDate t)throws SQLException{return dal.doanhThu(f,t);}
    public String sanPhamBanChay()throws SQLException{return dal.sanPhamBanChay();}
}
