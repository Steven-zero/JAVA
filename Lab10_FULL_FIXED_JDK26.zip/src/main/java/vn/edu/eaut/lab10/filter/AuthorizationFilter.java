package vn.edu.eaut.lab10.filter;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.*;
import java.io.IOException;
import vn.edu.eaut.lab10.model.Role;
import vn.edu.eaut.lab10.model.User;

@WebFilter(urlPatterns = {
        "/admin/*",
        "/staff/*",
        "/students",
        "/students/*",
        "/books",
        "/books/*",
        "/products",
        "/products/*"
})
public class AuthorizationFilter implements Filter {
    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;
        User user = (User) request.getSession(false).getAttribute("currentUser");

        String path = request.getRequestURI();
        String context = request.getContextPath();

        boolean adminPath = path.equals(context + "/admin") || path.startsWith(context + "/admin/");
        boolean staffPath = path.equals(context + "/staff") || path.startsWith(context + "/staff/");
        boolean businessPath =
                path.equals(context + "/students") || path.startsWith(context + "/students/") ||
                path.equals(context + "/books") || path.startsWith(context + "/books/") ||
                path.equals(context + "/products") || path.startsWith(context + "/products/");

        if (adminPath && user.getRole() != Role.ADMIN) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        if (staffPath &&
                user.getRole() != Role.ADMIN &&
                user.getRole() != Role.STAFF) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        if (businessPath &&
                user.getRole() != Role.ADMIN &&
                user.getRole() != Role.STAFF) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        chain.doFilter(req, res);
    }
}
