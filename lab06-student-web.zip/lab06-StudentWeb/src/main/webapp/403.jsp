<%@ page contentType="text/html;charset=UTF-8" %>
<html><head><title>403</title></head>
<body>
<h1>403 - Không có quyền truy cập</h1>
<p>Tài khoản User chỉ được xem danh sách sinh viên.</p>
<a href="${pageContext.request.contextPath}/students">Quay lại danh sách</a>
</body></html>
