package vn.edu.eaut.lab8.bean;

import jakarta.enterprise.context.RequestScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;

@Named("loginBean")
@RequestScoped
public class LoginBean {
    private String username;
    private String password;

    public String login() {
        if ("admin".equals(username) && "123456".equals(password)) {
            return "index?faces-redirect=true";
        }
        FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Đăng nhập thất bại",
                        "Sai tài khoản hoặc mật khẩu."));
        return null;
    }
    public String getUsername(){return username;} public void setUsername(String v){username=v;}
    public String getPassword(){return password;} public void setPassword(String v){password=v;}
}
