# BÁO CÁO LAB 6 - CHƯƠNG 3
## Xây dựng ứng dụng Web quản lý sinh viên bằng Servlet, JSP, JSTL theo mô hình MVC

### 1. Mục tiêu
Ứng dụng minh họa Servlet xử lý request, JSP/JSTL hiển thị dữ liệu, Session lưu trạng thái đăng nhập, Filter kiểm tra quyền truy cập, Listener theo dõi vòng đời ứng dụng/session và MVC tách Model - View - Controller.

### 2. Kiến trúc
- Model: `Student.java`
- Store: `StudentStore.java`
- Controller: các Servlet
- View: JSP
- Filter: AuthFilter, AdminFilter, AccessLogFilter
- Listener: AppContextListener, SessionLogListener

### 3. Luồng xử lý
Người dùng -> JSP/Form -> Servlet -> Store/Model -> request.setAttribute -> JSP -> Response.

### 4. Chức năng đã thực hiện
1. Hello Servlet.
2. Thêm sinh viên.
3. Hiển thị danh sách bằng JSTL.
4. Đăng nhập bằng Session.
5. AuthFilter và Listener.
6. Tìm kiếm sinh viên không phân biệt hoa thường.
7. Xóa sinh viên.
8. Cập nhật sinh viên, không cho sửa mã.
9. Phân quyền Admin/User.
10. Dashboard.
11. Ghi log URI, method, user, thời gian.
12. Listener tạo 5 sinh viên mẫu khi ứng dụng khởi động.

### 5. Tài khoản kiểm thử
Admin: admin / 123456
User: user / 123456

### 6. Hạn chế
Dữ liệu lưu trong bộ nhớ nên mất khi Tomcat khởi động lại. Lab 8 có thể mở rộng Store sang JDBC/JPA và cơ sở dữ liệu.

### 7. Minh chứng cần chụp
- Trang login.
- `/hello`.
- Dashboard Admin.
- Danh sách sinh viên.
- Thêm sinh viên.
- Tìm kiếm.
- Sửa.
- Xóa.
- Đăng nhập User và màn hình 403 khi thử chức năng quản trị.
- Console có log Filter/Listener.
