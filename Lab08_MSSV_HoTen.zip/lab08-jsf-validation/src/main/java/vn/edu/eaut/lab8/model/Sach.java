package vn.edu.eaut.lab8.model;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import java.io.Serializable;

public class Sach implements Serializable {
    @NotBlank(message="Tên sách không được để trống")
    private String tenSach;
    @NotBlank(message="Tác giả không được để trống")
    private String tacGia;
    @Min(value=1000, message="Năm xuất bản phải từ 1000 trở lên")
    private int namXuatBan;

    public Sach() {}
    public Sach(String tenSach, String tacGia, int namXuatBan) {
        this.tenSach=tenSach; this.tacGia=tacGia; this.namXuatBan=namXuatBan;
    }
    public String getTenSach(){return tenSach;} public void setTenSach(String v){tenSach=v;}
    public String getTacGia(){return tacGia;} public void setTacGia(String v){tacGia=v;}
    public int getNamXuatBan(){return namXuatBan;} public void setNamXuatBan(int v){namXuatBan=v;}
}
