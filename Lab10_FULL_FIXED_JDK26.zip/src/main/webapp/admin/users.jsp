<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!doctype html>
<html>
<head>
    <link rel="stylesheet" href="../assets/style.css">
    <title>Quản lý tài khoản</title>
</head>
<body>
<div class="nav"><a href="../dashboard.jsp">Dashboard</a></div>

<div class="container">
    <h2>Quản lý tài khoản</h2>

    <c:if test="${not empty error}">
        <p class="error">${error}</p>
    </c:if>

    <form method="get" action="users">
        <label>Tìm kiếm theo email</label>
        <input name="keyword" type="text" value="${keyword}" placeholder="Nhập email hoặc một phần email">
        <button type="submit">Tìm kiếm</button>
        <a class="btn" href="users">Xóa tìm kiếm</a>
    </form>

    <hr>

    <form method="post" action="users">
        <input type="hidden" name="id" value="${item.id}">

        <label>Email</label>
        <input name="email" type="email" value="${item.email}" required>

        <label>Họ tên</label>
        <input name="fullName" value="${item.fullName}" required>

        <label>Mật khẩu (để trống khi sửa nếu không đổi)</label>
        <input name="password" type="password">

        <label>Role</label>
        <select name="role" required>
            <option value="ADMIN" ${item.role == 'ADMIN' ? 'selected' : ''}>ADMIN</option>
            <option value="STAFF" ${item.role == 'STAFF' ? 'selected' : ''}>STAFF</option>
            <option value="USER" ${item.role == 'USER' ? 'selected' : ''}>USER</option>
        </select>

        <label>
            <input style="width:auto" type="checkbox" name="active"
                   ${empty item || item.active ? 'checked' : ''}>
            Hoạt động
        </label>

        <button type="submit">Lưu tài khoản</button>
        <a class="btn" href="users">Làm mới</a>
    </form>

    <table>
        <tr>
            <th>ID</th><th>Email</th><th>Họ tên</th><th>Role</th>
            <th>Active</th><th>Thao tác</th>
        </tr>
        <c:forEach var="x" items="${items}">
            <tr>
                <td>${x.id}</td>
                <td>${x.email}</td>
                <td>${x.fullName}</td>
                <td>${x.role}</td>
                <td>${x.active}</td>
                <td>
                    <a class="btn" href="users?action=edit&id=${x.id}">Sửa</a>
                    <a class="btn danger" href="users?action=delete&id=${x.id}"
                       onclick="return confirm('Xóa tài khoản?')">Xóa</a>
                </td>
            </tr>
        </c:forEach>
    </table>
</div>
</body>
</html>
