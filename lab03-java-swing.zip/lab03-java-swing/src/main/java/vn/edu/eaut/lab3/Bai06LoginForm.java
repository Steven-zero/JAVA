package vn.edu.eaut.lab3;

import javax.swing.*;
import java.awt.*;
import java.util.Arrays;

/**
 * Bài 6 - Form đăng nhập cơ bản.
 * Tài khoản kiểm thử: admin/123456 (vai trò Admin); user/123456 (vai trò User).
 */
public class Bai06LoginForm extends JFrame {

    private final JTextField txtUsername = new JTextField();
    private final JPasswordField txtPassword = new JPasswordField();
    private final JComboBox<String> cbRole = new JComboBox<>(new String[]{"Admin", "User"});
    private final JCheckBox chkShowPassword = new JCheckBox("Hiển thị mật khẩu");
    private final char echoChar;

    public Bai06LoginForm() {
        setTitle("Bài 6 - Form đăng nhập cơ bản");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        echoChar = txtPassword.getEchoChar();

        JPanel formPanel = new JPanel(new GridLayout(4, 2, 8, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 5, 15));

        formPanel.add(new JLabel("Tài khoản:"));
        formPanel.add(txtUsername);

        formPanel.add(new JLabel("Mật khẩu:"));
        formPanel.add(txtPassword);

        formPanel.add(new JLabel("Vai trò:"));
        formPanel.add(cbRole);

        formPanel.add(new JLabel(""));
        formPanel.add(chkShowPassword);

        JButton btnLogin = new JButton("Đăng nhập");
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.add(btnLogin);

        chkShowPassword.addActionListener(e ->
                txtPassword.setEchoChar(chkShowPassword.isSelected() ? (char) 0 : echoChar));

        btnLogin.addActionListener(e -> xuLyDangNhap());

        add(formPanel, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        setSize(380, 240);
        setLocationRelativeTo(null);
    }

    private void xuLyDangNhap() {
        String username = txtUsername.getText().trim();
        char[] passChars = txtPassword.getPassword();
        String password = new String(passChars);
        String role = (String) cbRole.getSelectedItem();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ tài khoản và mật khẩu!",
                    "Thiếu dữ liệu", JOptionPane.WARNING_MESSAGE);
            Arrays.fill(passChars, '0');
            return;
        }

        boolean hopLe;
        if ("Admin".equals(role)) {
            hopLe = username.equals("admin") && password.equals("123456");
        } else {
            hopLe = username.equals("user") && password.equals("123456");
        }

        if (hopLe) {
            JOptionPane.showMessageDialog(this,
                    "Chào mừng " + username + "! Đăng nhập thành công với vai trò " + role + ".",
                    "Thành công", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this,
                    "Sai tài khoản, mật khẩu hoặc vai trò không khớp. Vui lòng thử lại!",
                    "Đăng nhập thất bại", JOptionPane.ERROR_MESSAGE);
        }

        Arrays.fill(passChars, '0');
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Bai06LoginForm().setVisible(true));
    }
}
