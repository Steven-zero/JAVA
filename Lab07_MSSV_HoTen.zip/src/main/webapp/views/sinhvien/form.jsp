<%@ page contentType="text/html;charset=UTF-8" %>
<!doctype html><html><head><meta charset="UTF-8"><title>Form sinh viên</title>
<style>body{font-family:Arial;background:#f4f6f8}.box{width:500px;margin:40px auto;background:white;padding:25px;border-radius:12px}input{width:100%;padding:9px;margin:6px 0 15px;box-sizing:border-box}button{padding:10px 20px}</style>
</head><body><div class="box"><h2>${empty sv ? 'Thêm sinh viên' : 'Sửa sinh viên'}</h2>
<form method="post" action="${pageContext.request.contextPath}/sinh-vien">
<input type="hidden" name="id" value="${sv.id}">
<label>Mã sinh viên</label><input name="maSinhVien" value="${sv.maSinhVien}" required>
<label>Họ tên</label><input name="hoTen" value="${sv.hoTen}" required>
<label>Email</label><input name="email" type="email" value="${sv.email}">
<label>Lớp</label><input name="lop" value="${sv.lop}">
<button type="submit">Lưu</button> <a href="${pageContext.request.contextPath}/sinh-vien">Hủy</a>
</form></div></body></html>