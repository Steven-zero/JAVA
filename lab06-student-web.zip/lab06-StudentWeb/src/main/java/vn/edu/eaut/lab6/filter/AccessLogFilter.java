package vn.edu.eaut.lab6.filter;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebFilter("/*")
public class AccessLogFilter implements Filter {
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        long start = System.currentTimeMillis();
        HttpServletRequest req = (HttpServletRequest) request;
        HttpSession session = req.getSession(false);
        String user = session == null ? "anonymous" : String.valueOf(session.getAttribute("username"));

        chain.doFilter(request, response);

        long time = System.currentTimeMillis() - start;
        System.out.println("[ACCESS] user=" + user + ", method=" + req.getMethod()
                + ", uri=" + req.getRequestURI() + ", time=" + time + "ms");
    }
}
