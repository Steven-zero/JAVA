package vn.edu.eaut.lab5.ui;

import vn.edu.eaut.lab5.bus.SanPhamBUS;
import vn.edu.eaut.lab5.model.SanPham;
import vn.edu.eaut.lab5.util.MessageUtil;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;

public class SanPhamPanel extends JPanel {
    JTextField txtId=new JTextField(),txtTen=new JTextField(),txtGia=new JTextField(),txtSL=new JTextField(),txtSearch=new JTextField();
    DefaultTableModel model=new DefaultTableModel(new Object[]{"Mã","Tên sản phẩm","Đơn giá","Số lượng"},0);
    JTable table=new JTable(model);
    SanPhamBUS bus=new SanPhamBUS();

    public SanPhamPanel(){
        setLayout(new BorderLayout(8,8));
        JPanel form=new JPanel(new GridLayout(2,5,5,5));
        form.add(new JLabel("Mã"));form.add(new JLabel("Tên"));form.add(new JLabel("Đơn giá"));form.add(new JLabel("Số lượng"));form.add(new JLabel("Tìm kiếm"));
        form.add(txtId);form.add(txtTen);form.add(txtGia);form.add(txtSL);form.add(txtSearch);
        txtId.setEditable(false); add(form,BorderLayout.NORTH); add(new JScrollPane(table),BorderLayout.CENTER);
        JPanel buttons=new JPanel();
        JButton add=new JButton("Thêm"),edit=new JButton("Sửa"),del=new JButton("Xóa"),clear=new JButton("Làm mới"),search=new JButton("Tìm");
        for(JButton b:new JButton[]{add,edit,del,clear,search})buttons.add(b);add(buttons,BorderLayout.SOUTH);
        table.getSelectionModel().addListSelectionListener(e->{int r=table.getSelectedRow();if(r>=0){txtId.setText(model.getValueAt(r,0).toString());txtTen.setText(model.getValueAt(r,1).toString());txtGia.setText(model.getValueAt(r,2).toString());txtSL.setText(model.getValueAt(r,3).toString());}});
        add.addActionListener(e->save(0)); edit.addActionListener(e->save(Integer.parseInt(txtId.getText().isEmpty()?"0":txtId.getText())));
        del.addActionListener(e->{try{if(bus.delete(Integer.parseInt(txtId.getText()))) {MessageUtil.info(this,"Đã xóa");load();clear();}}catch(Exception x){MessageUtil.error(this,x.getMessage());}});
        clear.addActionListener(e->clear());search.addActionListener(e->loadSearch());
        load();
    }
    void save(int id){try{SanPham s=new SanPham(id,txtTen.getText(),new BigDecimal(txtGia.getText()),Integer.parseInt(txtSL.getText()));if(bus.save(s)){MessageUtil.info(this,id==0?"Đã thêm":"Đã sửa");load();clear();}}catch(Exception e){MessageUtil.error(this,e.getMessage());}}
    void load(){try{model.setRowCount(0);for(SanPham s:bus.findAll())model.addRow(new Object[]{s.getMaSp(),s.getTenSp(),s.getDonGia(),s.getSoLuong()});}catch(Exception e){MessageUtil.error(this,e.getMessage());}}
    void loadSearch(){try{model.setRowCount(0);for(SanPham s:bus.search(txtSearch.getText()))model.addRow(new Object[]{s.getMaSp(),s.getTenSp(),s.getDonGia(),s.getSoLuong()});}catch(Exception e){MessageUtil.error(this,e.getMessage());}}
    void clear(){txtId.setText("");txtTen.setText("");txtGia.setText("");txtSL.setText("");}
}
