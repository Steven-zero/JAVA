package vn.edu.eaut.lab10.model;
import jakarta.persistence.*;
@Entity @Table(name="books")
public class Book {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Integer id;
 @Column(nullable=false,length=150) private String title;
 @Column(nullable=false,length=100) private String author;
 @Column(nullable=false) private Integer quantity;
 @Column(nullable=false) private Double price;
 public Book(){} public Integer getId(){return id;} public void setId(Integer v){id=v;} public String getTitle(){return title;} public void setTitle(String v){title=v;} public String getAuthor(){return author;} public void setAuthor(String v){author=v;} public Integer getQuantity(){return quantity;} public void setQuantity(Integer v){quantity=v;} public Double getPrice(){return price;} public void setPrice(Double v){price=v;}
}