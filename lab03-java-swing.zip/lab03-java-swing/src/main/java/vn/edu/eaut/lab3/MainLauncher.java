package vn.edu.eaut.lab3;

import javax.swing.*;
import java.awt.*;

/**
 * MainLauncher - Màn hình menu để chạy nhanh từng bài tập trong Lab 3.
 * Mỗi bài sẽ mở trong một cửa sổ JFrame riêng, có thể mở nhiều bài cùng lúc.
 *
 * Chạy bằng Maven:
 *   mvn exec:java -Dexec.mainClass="vn.edu.eaut.lab3.MainLauncher"
 * Hoặc chạy trực tiếp file này trong IDE.
 */
public class MainLauncher extends JFrame {

    public MainLauncher() {
        setTitle("Lab 3 - Java Swing - Danh sách bài tập");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JLabel lblTitle = new JLabel("CHỌN BÀI TẬP ĐỂ CHẠY", SwingConstants.CENTER);
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 18));
        lblTitle.setBorder(BorderFactory.createEmptyBorder(15, 10, 5, 10));
        add(lblTitle, BorderLayout.NORTH);

        String[][] danhSachBai = {
                {"Bài 1 - Chào người dùng", "Bai01HelloSwing"},
                {"Bài 2 - Tính tổng hai số", "Bai02TongHaiSo"},
                {"Bài 3 - Giải phương trình bậc nhất", "Bai03PhuongTrinhBacNhat"},
                {"Bài 4 - Kiểm tra và phân loại tam giác", "Bai04TamGiacSwing"},
                {"Bài 5 - Hiển thị n số Fibonacci", "Bai05FibonacciSwing"},
                {"Bài 6 - Form đăng nhập cơ bản", "Bai06LoginForm"},
                {"Bài 7 - Máy tính mini", "Bai07MayTinhMini"},
                {"Bài 8 - Quản lý sinh viên bằng JTable", "Bai08QuanLySinhVien"}
        };

        JPanel listPanel = new JPanel(new GridLayout(danhSachBai.length, 1, 5, 8));
        listPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        for (String[] bai : danhSachBai) {
            JButton btn = new JButton(bai[0]);
            btn.setHorizontalAlignment(SwingConstants.LEFT);
            btn.addActionListener(e -> moBai(bai[1]));
            listPanel.add(btn);
        }

        JButton btnMoTatCa = new JButton("Mở TẤT CẢ các bài cùng lúc");
        btnMoTatCa.setFont(new Font("SansSerif", Font.BOLD, 13));
        btnMoTatCa.addActionListener(e -> {
            for (String[] bai : danhSachBai) {
                moBai(bai[1]);
            }
        });

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        bottomPanel.add(btnMoTatCa);

        add(new JScrollPane(listPanel), BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        setSize(420, 500);
        setLocationRelativeTo(null);
    }

    /**
     * Mở cửa sổ của bài tập tương ứng theo tên lớp, chạy trên EDT.
     */
    private void moBai(String tenLop) {
        SwingUtilities.invokeLater(() -> {
            try {
                switch (tenLop) {
                    case "Bai01HelloSwing":
                        new Bai01HelloSwing().setVisible(true);
                        break;
                    case "Bai02TongHaiSo":
                        new Bai02TongHaiSo().setVisible(true);
                        break;
                    case "Bai03PhuongTrinhBacNhat":
                        new Bai03PhuongTrinhBacNhat().setVisible(true);
                        break;
                    case "Bai04TamGiacSwing":
                        new Bai04TamGiacSwing().setVisible(true);
                        break;
                    case "Bai05FibonacciSwing":
                        new Bai05FibonacciSwing().setVisible(true);
                        break;
                    case "Bai06LoginForm":
                        new Bai06LoginForm().setVisible(true);
                        break;
                    case "Bai07MayTinhMini":
                        new Bai07MayTinhMini().setVisible(true);
                        break;
                    case "Bai08QuanLySinhVien":
                        new Bai08QuanLySinhVien().setVisible(true);
                        break;
                    default:
                        JOptionPane.showMessageDialog(this, "Không tìm thấy bài: " + tenLop);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this,
                        "Lỗi khi mở " + tenLop + ": " + ex.getMessage(),
                        "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainLauncher().setVisible(true));
    }
}
