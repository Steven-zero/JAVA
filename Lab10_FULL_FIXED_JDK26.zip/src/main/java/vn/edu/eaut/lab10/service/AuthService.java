package vn.edu.eaut.lab10.service;

import vn.edu.eaut.lab10.model.LoginLog;
import vn.edu.eaut.lab10.model.User;
import vn.edu.eaut.lab10.repository.LogRepository;
import vn.edu.eaut.lab10.repository.UserRepository;

public class AuthService {
    private final UserRepository repo = new UserRepository();
    private final LogRepository logs = new LogRepository();

    public User login(String email, String password, String ip) {
        if (email == null || email.isBlank() || password == null || password.isBlank()) {
            return null;
        }

        User u = repo.findByEmail(email.trim());
        if (u == null || !u.isActive() || !password.equals(u.getPassword())) {
            logs.save(new LoginLog(email.trim(), "LOGIN_FAIL", ip));
            return null;
        }

        logs.save(new LoginLog(u.getEmail(), "LOGIN_SUCCESS", ip));
        return u;
    }

    public void logout(String email, String ip) {
        if (email != null && !email.isBlank()) {
            logs.save(new LoginLog(email, "LOGOUT", ip));
        }
    }
}
