package vn.edu.eaut.lab6.controller;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import jakarta.servlet.ServletException;
import vn.edu.eaut.lab6.store.StudentStore;
import java.io.IOException;

@WebServlet("/students/edit")
public class EditStudentServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        var student = StudentStore.findById(request.getParameter("id"));
        if (student == null) {
            response.sendRedirect(request.getContextPath() + "/students");
            return;
        }
        request.setAttribute("student", student);
        request.getRequestDispatcher("/student-edit.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String id = request.getParameter("id");
        StudentStore.update(id, request.getParameter("name"),
                request.getParameter("className"), request.getParameter("email"));
        response.sendRedirect(request.getContextPath() + "/students");
    }
}
