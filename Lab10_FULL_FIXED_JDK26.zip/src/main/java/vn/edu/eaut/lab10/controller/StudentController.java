package vn.edu.eaut.lab10.controller;
import jakarta.servlet.*; import jakarta.servlet.annotation.WebServlet; import jakarta.servlet.http.*; import java.io.*; import vn.edu.eaut.lab10.model.Student; import vn.edu.eaut.lab10.repository.GenericRepository;
@WebServlet("/students") public class StudentController extends HttpServlet {
 private final GenericRepository<Student> repo=new GenericRepository<>(Student.class);
 protected void doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException {
  String action=req.getParameter("action"); if("delete".equals(action)){repo.delete(Integer.valueOf(req.getParameter("id")));resp.sendRedirect(req.getContextPath()+"/students");return;}
  if("edit".equals(action)) req.setAttribute("item",repo.find(Integer.valueOf(req.getParameter("id"))));
  req.setAttribute("items",repo.findAll()); req.getRequestDispatcher("/students/index.jsp").forward(req,resp);
 }
 protected void doPost(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException {
  req.setCharacterEncoding("UTF-8"); try {
   String id=req.getParameter("id"); String code=req.getParameter("code");
String fullName=req.getParameter("fullName");
String email=req.getParameter("email");
String major=req.getParameter("major");
   Student obj;
   if(id==null||id.isBlank()) obj=new Student(); else obj=repo.find(Integer.valueOf(id));
   obj.setCode(code);
obj.setFullName(fullName);
obj.setEmail(email);
obj.setMajor(major);
   if(id==null||id.isBlank())repo.save(obj);else repo.update(obj);
   resp.sendRedirect(req.getContextPath()+"/students");
  } catch(Exception e) {req.setAttribute("error","Dữ liệu không hợp lệ: "+e.getMessage());req.setAttribute("items",repo.findAll());req.getRequestDispatcher("/students/index.jsp").forward(req,resp);}
 }
}