<%@ page contentType="text/html;charset=UTF-8" %><%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!doctype html><html><head><link rel="stylesheet" href="assets/style.css"><title>Lab 10 Login</title></head><body>
<div class="container" style="max-width:420px;margin-top:80px"><h2>Đăng nhập hệ thống</h2><c:if test="${not empty error}"><p class="error">${error}</p></c:if>
<form method="post" action="auth"><label>Email</label><input type="email" name="email" required><label>Mật khẩu</label><input type="password" name="password" required><button>Đăng nhập</button></form>
<hr><p><b>Demo:</b> admin@eaut.edu.vn / 123456</p><p>staff@eaut.edu.vn / 123456</p><p>user@eaut.edu.vn / 123456</p></div></body></html>