<%@ page contentType="text/html;charset=UTF-8" %>
<!doctype html><html><head><meta charset="UTF-8"><title>Đăng nhập</title>
<style>body{font-family:Arial;background:#eef2f7}.box{width:360px;margin:80px auto;background:white;padding:28px;border-radius:12px}input{width:100%;padding:10px;margin:8px 0;box-sizing:border-box}button{width:100%;padding:10px;background:#2563eb;color:white;border:0;border-radius:6px}</style>
</head><body><div class="box"><h2>Đăng nhập quản trị</h2>
<% if(request.getParameter("error")!=null){ %><p style="color:red">Sai tài khoản hoặc mật khẩu.</p><% } %>
<form method="post" action="${pageContext.request.contextPath}/login">
<input name="username" placeholder="Tài khoản" required>
<input name="password" type="password" placeholder="Mật khẩu" required>
<button>Đăng nhập</button></form>
<p>Tài khoản mẫu: <b>admin</b> / <b>123456</b></p>
</div></body></html>