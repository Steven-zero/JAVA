package vn.edu.eaut.lab5.ui;

import vn.edu.eaut.lab5.bus.ThongKeBUS;
import javax.swing.*;import java.awt.*;import java.math.BigDecimal;import java.time.LocalDate;

public class ThongKePanel extends JPanel {
    JTextField from=new JTextField(LocalDate.now().withDayOfMonth(1).toString()),to=new JTextField(LocalDate.now().toString());
    JLabel result=new JLabel("Doanh thu: "); ThongKeBUS bus=new ThongKeBUS();
    public ThongKePanel(){setLayout(new FlowLayout(FlowLayout.LEFT));add(new JLabel("Từ ngày"));add(from);add(new JLabel("Đến ngày"));add(to);JButton b=new JButton("Thống kê");add(b);add(result);b.addActionListener(e->run());}
    void run(){new SwingWorker<BigDecimal,Void>(){
        protected BigDecimal doInBackground() throws Exception{return bus.tinhDoanhThu(LocalDate.parse(from.getText()),LocalDate.parse(to.getText()));}
        protected void done(){try{result.setText("Doanh thu: "+get()+" VND");}catch(Exception e){result.setText("Lỗi: "+e.getMessage());}}
    }.execute();}
}
