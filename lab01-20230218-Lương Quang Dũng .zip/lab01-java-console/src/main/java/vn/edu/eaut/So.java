package vn.edu.eaut.lab1;

public class So {

    // Bài 1
    public static int tongChanDenN(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException("n phai la so nguyen duong");
        }

        int tong = 0;

        for (int i = 2; i <= n; i += 2) {
            tong += i;
        }

        return tong;
    }

    // Bài 2
    public static double tongNghichDao(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException("n phai la so nguyen duong");
        }

        double tong = 0;

        for (int i = 1; i <= n; i++) {
            tong += 1.0 / i;
        }

        return tong;
    }

    // Bài 3
    public static boolean laSoNguyenTo(int n) {

        if (n < 2)
            return false;

        if (n == 2)
            return true;

        if (n % 2 == 0)
            return false;

        for (int i = 3; i <= Math.sqrt(n); i += 2) {

            if (n % i == 0)
                return false;

        }

        return true;
    }

    // Bài 4
    public static String loaiTamGiac(double a, double b, double c) {

        if (a <= 0 || b <= 0 || c <= 0)
            return "Khong phai tam giac";

        if (a + b <= c || a + c <= b || b + c <= a)
            return "Khong phai tam giac";

        if (a == b && b == c)
            return "Tam giac deu";

        if (a * a + b * b == c * c ||
                a * a + c * c == b * b ||
                b * b + c * c == a * a) {

            if (a == b || a == c || b == c)
                return "Tam giac vuong can";

            return "Tam giac vuong";
        }

        if (a == b || a == c || b == c)
            return "Tam giac can";

        return "Tam giac thuong";
    }

    // Bài 5
    public static String dayFibonacci(int n) {

        if (n <= 0) {
            throw new IllegalArgumentException("n phai la so nguyen duong");
        }

        StringBuilder sb = new StringBuilder();

        long a = 0;
        long b = 1;

        for (int i = 1; i <= n; i++) {

            sb.append(a).append(" ");

            long c = a + b;

            a = b;
            b = c;
        }

        return sb.toString();
    }

}