# BÁO CÁO LAB 8 – CHUYỂN FORM SANG JSF, VALIDATION VÀ MESSAGE

## 1. Thông tin bài lab
- Học phần: Công nghệ Java (IT3242)
- Chương: Phát triển ứng dụng đa lớp trong Jakarta EE
- Nội dung: Jakarta Faces/JSF, Facelets XHTML, CDI Bean, Bean Validation và FacesMessage.
- Project: `lab08-jsf-validation`

## 2. Mục tiêu
1. Hiểu sự khác nhau giữa Servlet + JSP và JSF.
2. Cấu hình FacesServlet để chạy trang XHTML.
3. Xây dựng form JSF bằng `h:form`, `h:inputText`, `h:commandButton`.
4. Dùng CDI/Managed Bean nhận dữ liệu từ giao diện.
5. Kiểm tra dữ liệu bằng Bean Validation và thuộc tính `required`.
6. Hiển thị lỗi theo trường và thông báo thành công bằng `h:message`, `h:messages`.
7. Hiển thị danh sách bằng `h:dataTable`.

## 3. Cấu trúc project
```text
lab08-jsf-validation/
├── pom.xml
└── src/main/
    ├── java/vn/edu/eaut/lab8/
    │   ├── bean/SinhVienBean.java
    │   ├── model/SinhVien.java
    │   └── repository/SinhVienRepository.java
    └── webapp/
        ├── index.xhtml
        ├── sinhvien-form.xhtml
        ├── sinhvien-list.xhtml
        └── WEB-INF/
            ├── web.xml
            └── beans.xml
```

## 4. Công nghệ và cấu hình
Project dùng Maven WAR, JDK 17, Jakarta Faces 4.0.7, Weld Servlet 5.1.2.Final và Hibernate Validator 8.0.1.Final.

`web.xml` đăng ký `jakarta.faces.webapp.FacesServlet` và ánh xạ URL `*.xhtml`.

## 5. Mô hình xử lý
Người dùng mở `index.xhtml` → chọn form → nhập dữ liệu → JSF thực hiện lifecycle gồm Restore View, Apply Request Values, Process Validations, Update Model Values và Invoke Application → nếu hợp lệ thì gọi `SinhVienBean.save()` → Repository thêm sinh viên vào `List` → `FacesMessage` thông báo thành công.

Nếu dữ liệu không hợp lệ, quá trình validation tạo lỗi và `h:message` hiển thị lỗi ngay tại trường tương ứng; phương thức `save()` không được thực hiện.

## 6. Validation
Các trường được kiểm tra:
- Mã sinh viên: không được để trống.
- Họ tên: không được để trống, tối thiểu 5 ký tự.
- Email: không được để trống và phải đúng định dạng email.
- Lớp: không được để trống.

## 7. Chức năng đã thực hiện
- Trang chủ JSF.
- Form thêm sinh viên.
- Validation dữ liệu.
- Thông báo thành công.
- Hiển thị danh sách sinh viên.
- Xóa sinh viên.
- Lưu dữ liệu trong bộ nhớ bằng `List`, chưa dùng JPA/database theo phạm vi Lab 8.

## 8. So sánh Servlet/JSP và JSF
| Nội dung | Servlet + JSP | JSF |
|---|---|---|
| Giao diện | JSP/HTML/JSTL | Facelets XHTML + JSF components |
| Xử lý form | Servlet đọc request | Component tree + JSF lifecycle |
| Validation | Tự xử lý hoặc thư viện | Validator/Bean Validation |
| Message | Tự truyền attribute/request | FacesMessage + h:messages |
| Binding | request.getParameter | EL binding tới Bean |
| Điều hướng | RequestDispatcher/redirect | outcome/action |

## 9. Kết quả
Project đáp ứng các yêu cầu tổng hợp của Lab 8: có tối thiểu 2 trang XHTML, Bean nhận và xử lý dữ liệu, Repository lưu danh sách, validation nhiều trường, message lỗi/thành công và bảng `h:dataTable`.

## 10. Cách chạy
1. Cài JDK 17.
2. Cài Maven.
3. Cài Apache Tomcat 10.x.
4. Mở project bằng IntelliJ IDEA/Eclipse/NetBeans.
5. Maven tải dependency.
6. Build WAR bằng `mvn clean package`.
7. Deploy `target/lab08-jsf-validation.war` lên Tomcat 10.x.
8. Mở `/lab08-jsf-validation/index.xhtml`.

## 11. Ảnh minh chứng
Khi chạy thực tế, chụp tối thiểu:
- Trang chủ.
- Form sinh viên khi để trống/sai dữ liệu để chứng minh validation.
- Form sau khi lưu thành công.
- Trang danh sách sinh viên.
- Danh sách sau khi xóa.

## 12. Câu hỏi củng cố
**1. JSF xử lý form khác Servlet/JSP ở điểm nào?**  
JSF sử dụng component-based UI và JSF lifecycle để nhận dữ liệu, validation, cập nhật model và gọi action của Bean; Servlet/JSP thường xử lý request/response trực tiếp.

**2. Vai trò của h:inputText, h:commandButton, h:messages?**  
`h:inputText` nhận dữ liệu; `h:commandButton` gửi form và gọi action; `h:messages` hiển thị các thông báo FacesMessage.

**3. Managed Bean nhận dữ liệu bằng cơ chế nào?**  
Thông qua Expression Language (EL) binding giữa thuộc tính component JSF và thuộc tính của Bean.

**4. Bean Validation khác requiredMessage thế nào?**  
`requiredMessage` kiểm tra trường bắt buộc ở component JSF. Bean Validation dùng annotation như `@NotBlank`, `@Size`, `@Email` để áp dụng các ràng buộc nghiệp vụ trên model.

**5. Vì sao Lab 9 mới tích hợp JPA, Entity, Repository và transaction?**  
Theo phạm vi bài lab, Lab 8 tập trung vào JSF, validation và message; JPA, Entity, Repository và transaction được để sang Lab 9 để tách riêng nội dung persistence và transaction.
