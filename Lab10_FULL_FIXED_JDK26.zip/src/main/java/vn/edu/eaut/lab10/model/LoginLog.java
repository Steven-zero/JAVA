package vn.edu.eaut.lab10.model;
import jakarta.persistence.*;
@Entity @Table(name="login_logs")
public class LoginLog {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false) private String email;
 @Column(nullable=false) private String action;
 @Column(name="ip_address") private String ipAddress;
 @Column(name="created_at",nullable=false) private java.time.LocalDateTime createdAt;
 public LoginLog(){} public LoginLog(String e,String a,String ip){email=e;action=a;ipAddress=ip;createdAt=java.time.LocalDateTime.now();}
 public Long getId(){return id;} public String getEmail(){return email;} public String getAction(){return action;} public String getIpAddress(){return ipAddress;} public java.time.LocalDateTime getCreatedAt(){return createdAt;}
}