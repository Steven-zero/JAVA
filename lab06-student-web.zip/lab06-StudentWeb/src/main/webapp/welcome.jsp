<%@ page contentType="text/html;charset=UTF-8" %>
<html><head><title>Dashboard</title>
<style>body{font-family:Arial;margin:40px}a{display:inline-block;margin:8px;padding:10px 16px;background:#eee;text-decoration:none}</style>
</head><body>
<h2>Xin chào, ${sessionScope.username}</h2>
<p>Vai trò: <b>${sessionScope.role}</b></p>
<p>Tổng số sinh viên hiện tại: <b>${applicationScope.studentCount}</b></p>
<a href="${pageContext.request.contextPath}/students">Quản lý sinh viên</a>
<a href="${pageContext.request.contextPath}/logout">Đăng xuất</a>
</body></html>
