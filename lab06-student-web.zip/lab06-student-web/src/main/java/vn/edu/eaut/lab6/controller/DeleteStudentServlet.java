package vn.edu.eaut.lab6.controller;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import jakarta.servlet.ServletException;
import vn.edu.eaut.lab6.store.StudentStore;
import java.io.IOException;

@WebServlet("/students/delete")
public class DeleteStudentServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        StudentStore.delete(request.getParameter("id"));
        response.sendRedirect(request.getContextPath() + "/students");
    }
}
