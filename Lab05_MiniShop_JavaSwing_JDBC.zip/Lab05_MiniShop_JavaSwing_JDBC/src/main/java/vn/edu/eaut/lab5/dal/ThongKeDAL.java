package vn.edu.eaut.lab5.dal;

import vn.edu.eaut.lab5.config.DBHelper;
import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDate;

public class ThongKeDAL {
    public BigDecimal doanhThu(LocalDate from,LocalDate to)throws SQLException{
        String sql="SELECT COALESCE(SUM(tong_tien),0) FROM hoa_don WHERE ngay_lap BETWEEN ? AND ?";
        try(Connection c=DBHelper.getConnection();PreparedStatement p=c.prepareStatement(sql)){
            p.setDate(1,Date.valueOf(from));p.setDate(2,Date.valueOf(to));
            try(ResultSet r=p.executeQuery()){r.next();return r.getBigDecimal(1);}
        }
    }
    public String sanPhamBanChay()throws SQLException{
        String sql="SELECT sp.ten_sp,SUM(ct.so_luong) sl FROM chi_tiet_hoa_don ct JOIN san_pham sp ON ct.ma_sp=sp.ma_sp GROUP BY sp.ma_sp,sp.ten_sp ORDER BY sl DESC LIMIT 1";
        try(Connection c=DBHelper.getConnection();PreparedStatement p=c.prepareStatement(sql);ResultSet r=p.executeQuery()){
            return r.next()?r.getString("ten_sp")+" ("+r.getInt("sl")+" san pham)":"Chua co du lieu";
        }
    }
}
