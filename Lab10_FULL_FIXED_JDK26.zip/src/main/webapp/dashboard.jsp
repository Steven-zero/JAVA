<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="vn.edu.eaut.lab10.model.User" %>
<%
    User u = (User) session.getAttribute("currentUser");
    if (u == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
    boolean admin = u.getRole().name().equals("ADMIN");
    boolean staff = u.getRole().name().equals("STAFF");
%>
<!doctype html>
<html>
<head>
    <link rel="stylesheet" href="assets/style.css">
    <title>Dashboard</title>
</head>
<body>
<div class="nav">
    <a href="dashboard.jsp">Dashboard</a>

    <% if (admin || staff) { %>
        <a href="students">Sinh viên</a>
        <a href="books">Sách</a>
        <a href="products">Sản phẩm</a>
    <% } %>

    <a href="user/profile">Hồ sơ</a>
    <a href="user/password">Đổi mật khẩu</a>

    <% if (admin) { %>
        <a href="admin/users">Quản lý User</a>
        <a href="admin/logs">Log</a>
    <% } %>

    <% if (admin || staff) { %>
        <a href="staff/index.jsp">Nghiệp vụ</a>
    <% } %>

    <a href="auth?action=logout">Đăng xuất</a>
</div>

<div class="container">
    <h1>Dashboard Lab 10</h1>
    <p>Xin chào <b><%=u.getFullName()%></b> | Role: <b><%=u.getRole()%></b></p>

    <% if (admin || staff) { %>
    <div class="grid">
        <div class="card"><h3>Sinh viên</h3><a class="btn" href="students">Quản lý</a></div>
        <div class="card"><h3>Sách</h3><a class="btn" href="books">Quản lý</a></div>
        <div class="card"><h3>Sản phẩm</h3><a class="btn" href="products">Quản lý</a></div>
    </div>
    <% } else { %>
    <div class="card">
        <h3>Khu vực cá nhân</h3>
        <p>Bạn có thể xem/cập nhật hồ sơ và đổi mật khẩu.</p>
        <a class="btn" href="user/profile">Hồ sơ</a>
        <a class="btn" href="user/password">Đổi mật khẩu</a>
    </div>
    <% } %>

    <% if (admin) { %>
        <h3>Khu vực ADMIN</h3>
        <a class="btn" href="admin/users">Quản lý tài khoản</a>
        <a class="btn" href="admin/logs">Nhật ký đăng nhập</a>
    <% } %>
</div>
</body>
</html>
