# Lab 7 - CRUD Servlet + JSP + MVC

## Môi trường
- JDK 17
- Maven
- Tomcat 10.x
- IntelliJ IDEA / Eclipse / NetBeans

## Chạy
1. Mở project bằng IntelliJ.
2. Maven Reload/Load project.
3. Tạo Tomcat 10.x Server.
4. Deploy artifact `lab07-crud-mvc:war exploded`.
5. Run và mở `/lab07-crud-mvc/`.

## Tài khoản
- username: `admin`
- password: `123456`

## Chức năng đã làm
- Trang chủ
- CRUD sinh viên: thêm, sửa, xóa, xem chi tiết
- Tìm kiếm theo mã/tên/lớp
- JSP + JSTL
- Repository lưu List trong bộ nhớ
- Session đăng nhập
- LoginFilter bảo vệ `/admin/*`

Dữ liệu sẽ trở về dữ liệu mẫu khi ứng dụng/server khởi động lại vì Lab 7 yêu cầu lưu trong bộ nhớ.
