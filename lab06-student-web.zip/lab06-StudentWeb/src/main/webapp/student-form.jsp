<%@ page contentType="text/html;charset=UTF-8" %>
<%
    boolean editing = request.getAttribute("student") != null;
%>
<html><head><title><%= editing ? "Sửa sinh viên" : "Thêm sinh viên" %></title>
<style>body{font-family:Arial;margin:40px}.form{width:500px}input{width:100%;padding:9px;margin:6px 0 15px;box-sizing:border-box}</style>
</head><body>
<div class="form">
<h2><%= editing ? "Sửa sinh viên" : "Thêm sinh viên" %></h2>
<form action="${pageContext.request.contextPath}/students" method="post">
<input type="hidden" name="action" value="<%= editing ? "update" : "add" %>">
<label>Mã sinh viên:</label>
<input type="text" name="id" value="${student.id}" <%= editing ? "readonly" : "" %> required>
<label>Họ tên:</label>
<input type="text" name="name" value="${student.name}" required>
<label>Lớp:</label>
<input type="text" name="className" value="${student.className}" required>
<label>Email:</label>
<input type="email" name="email" value="${student.email}" required>
<button type="submit"><%= editing ? "Cập nhật" : "Lưu sinh viên" %></button>
</form>
<p><a href="${pageContext.request.contextPath}/students">Quay lại danh sách</a></p>
</div>
</body></html>
