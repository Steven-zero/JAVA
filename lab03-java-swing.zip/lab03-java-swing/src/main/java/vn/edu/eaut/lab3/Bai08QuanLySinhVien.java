package vn.edu.eaut.lab3;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Bài 8 - Quản lý sinh viên bằng JTable.
 * Lớp này đóng vai trò View/Controller, dữ liệu được lưu trong lớp Student (Model).
 */
public class Bai08QuanLySinhVien extends JFrame {

    private final List<Student> danhSachSinhVien = new ArrayList<>();

    private final JTextField txtMaSV = new JTextField();
    private final JTextField txtHoTen = new JTextField();
    private final JTextField txtDiem = new JTextField();

    private final String[] cotBang = {"Mã SV", "Họ tên", "Điểm TB", "Xếp loại"};
    private final DefaultTableModel tableModel = new DefaultTableModel(cotBang, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false; // không cho sửa trực tiếp trên bảng
        }
    };
    private final JTable table = new JTable(tableModel);

    public Bai08QuanLySinhVien() {
        setTitle("Bài 8 - Quản lý sinh viên");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Panel nhập liệu
        JPanel formPanel = new JPanel(new GridLayout(3, 2, 8, 8));
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        formPanel.add(new JLabel("Mã sinh viên:"));
        formPanel.add(txtMaSV);
        formPanel.add(new JLabel("Họ tên:"));
        formPanel.add(txtHoTen);
        formPanel.add(new JLabel("Điểm trung bình:"));
        formPanel.add(txtDiem);

        // Panel các nút chức năng
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        JButton btnThem = new JButton("Thêm");
        JButton btnSua = new JButton("Sửa");
        JButton btnXoa = new JButton("Xóa");
        JButton btnLamMoi = new JButton("Làm mới");
        btnPanel.add(btnThem);
        btnPanel.add(btnSua);
        btnPanel.add(btnXoa);
        btnPanel.add(btnLamMoi);

        btnThem.addActionListener(e -> themSinhVien());
        btnSua.addActionListener(e -> suaSinhVien());
        btnXoa.addActionListener(e -> xoaSinhVien());
        btnLamMoi.addActionListener(e -> lamMoiForm());

        // Khi chọn 1 dòng trên bảng, đổ dữ liệu vào form để sửa
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                doDuLieuTuBangVaoForm();
            }
        });

        JScrollPane scrollPane = new JScrollPane(table);

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(formPanel, BorderLayout.CENTER);
        topPanel.add(btnPanel, BorderLayout.SOUTH);

        add(topPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        setSize(560, 420);
        setLocationRelativeTo(null);
    }

    private void themSinhVien() {
        String maSV = txtMaSV.getText().trim();
        String hoTen = txtHoTen.getText().trim();

        if (maSV.isEmpty() || hoTen.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ mã sinh viên và họ tên!",
                    "Thiếu dữ liệu", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (timChiSoTheoMa(maSV) >= 0) {
            JOptionPane.showMessageDialog(this, "Mã sinh viên đã tồn tại!",
                    "Trùng dữ liệu", JOptionPane.WARNING_MESSAGE);
            return;
        }

        double diem;
        try {
            diem = Double.parseDouble(txtDiem.getText().trim());
            if (diem < 0 || diem > 10) {
                JOptionPane.showMessageDialog(this, "Điểm trung bình phải trong khoảng 0 đến 10!",
                        "Lỗi dữ liệu", JOptionPane.WARNING_MESSAGE);
                return;
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Điểm trung bình phải là số hợp lệ!",
                    "Lỗi nhập liệu", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Student sv = new Student(maSV, hoTen, diem);
        danhSachSinhVien.add(sv);
        capNhatBang();
        lamMoiForm();
    }

    private void suaSinhVien() {
        int dongChon = table.getSelectedRow();
        if (dongChon < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một sinh viên trong bảng để sửa!",
                    "Chưa chọn dòng", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String maSV = txtMaSV.getText().trim();
        String hoTen = txtHoTen.getText().trim();

        if (maSV.isEmpty() || hoTen.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ mã sinh viên và họ tên!",
                    "Thiếu dữ liệu", JOptionPane.WARNING_MESSAGE);
            return;
        }

        double diem;
        try {
            diem = Double.parseDouble(txtDiem.getText().trim());
            if (diem < 0 || diem > 10) {
                JOptionPane.showMessageDialog(this, "Điểm trung bình phải trong khoảng 0 đến 10!",
                        "Lỗi dữ liệu", JOptionPane.WARNING_MESSAGE);
                return;
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Điểm trung bình phải là số hợp lệ!",
                    "Lỗi nhập liệu", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String maCu = (String) tableModel.getValueAt(dongChon, 0);
        int chiSo = timChiSoTheoMa(maCu);
        if (chiSo < 0) return;

        // Nếu đổi mã SV thì kiểm tra trùng với sinh viên khác
        if (!maCu.equals(maSV) && timChiSoTheoMa(maSV) >= 0) {
            JOptionPane.showMessageDialog(this, "Mã sinh viên mới đã tồn tại!",
                    "Trùng dữ liệu", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Student sv = danhSachSinhVien.get(chiSo);
        sv.setMaSinhVien(maSV);
        sv.setHoTen(hoTen);
        sv.setDiemTrungBinh(diem);

        capNhatBang();
        lamMoiForm();
    }

    private void xoaSinhVien() {
        int dongChon = table.getSelectedRow();
        if (dongChon < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một sinh viên trong bảng để xóa!",
                    "Chưa chọn dòng", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int xacNhan = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn xóa sinh viên này?",
                "Xác nhận xóa", JOptionPane.YES_NO_OPTION);
        if (xacNhan != JOptionPane.YES_OPTION) return;

        String maSV = (String) tableModel.getValueAt(dongChon, 0);
        int chiSo = timChiSoTheoMa(maSV);
        if (chiSo >= 0) {
            danhSachSinhVien.remove(chiSo);
            capNhatBang();
            lamMoiForm();
        }
    }

    private void doDuLieuTuBangVaoForm() {
        int dongChon = table.getSelectedRow();
        if (dongChon < 0) return;

        txtMaSV.setText(String.valueOf(tableModel.getValueAt(dongChon, 0)));
        txtHoTen.setText(String.valueOf(tableModel.getValueAt(dongChon, 1)));
        txtDiem.setText(String.valueOf(tableModel.getValueAt(dongChon, 2)));
    }

    private int timChiSoTheoMa(String maSV) {
        for (int i = 0; i < danhSachSinhVien.size(); i++) {
            if (danhSachSinhVien.get(i).getMaSinhVien().equalsIgnoreCase(maSV)) {
                return i;
            }
        }
        return -1;
    }

    private void capNhatBang() {
        tableModel.setRowCount(0);
        for (Student sv : danhSachSinhVien) {
            tableModel.addRow(new Object[]{
                    sv.getMaSinhVien(),
                    sv.getHoTen(),
                    sv.getDiemTrungBinh(),
                    sv.xepLoai()
            });
        }
    }

    private void lamMoiForm() {
        txtMaSV.setText("");
        txtHoTen.setText("");
        txtDiem.setText("");
        table.clearSelection();
        txtMaSV.requestFocus();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Bai08QuanLySinhVien().setVisible(true));
    }
}
