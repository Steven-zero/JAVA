package vn.edu.eaut.lab6.listener;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebListener;
import vn.edu.eaut.lab6.store.StudentStore;

@WebListener
public class AppContextListener implements ServletContextListener {
    @Override
    public void contextInitialized(ServletContextEvent sce) {
        sce.getServletContext().setAttribute("studentCount", StudentStore.findAll().size());
        System.out.println("Ung dung Lab 6 da khoi dong - " + StudentStore.findAll().size() + " sinh vien");
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        System.out.println("Ung dung Lab 6 da dung - so sinh vien: " + StudentStore.findAll().size());
    }
}
