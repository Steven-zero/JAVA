# LAB 10 - ỨNG DỤNG QUẢN LÝ ĐA LỚP JAKARTA EE

## Môi trường
- JDK 26
- Apache Tomcat 10.1.x
- Maven
- MySQL 8.x
- IntelliJ IDEA
- Jakarta Servlet/JSP/JSTL
- JPA/Hibernate
- HttpSession + Filter + Listener
- Role: ADMIN / STAFF / USER

## Chức năng
- Login / Logout bằng dữ liệu CSDL.
- Lưu người dùng hiện tại trong HttpSession.
- AuthenticationFilter bảo vệ URL nội bộ.
- AuthorizationFilter phân quyền ADMIN / STAFF / USER.
- ADMIN quản lý tài khoản và xem log.
- STAFF/ADMIN quản lý Sinh viên, Sách, Sản phẩm.
- USER chỉ truy cập khu vực cá nhân.
- Hồ sơ cá nhân và đổi mật khẩu.
- 403 / 404 / 500.
- Ba module CRUD bằng JPA.
- Transaction ở repository.
- Validate phía form + kiểm tra phía server.
- Tìm kiếm tài khoản theo email.
- Database script và dữ liệu mẫu.

## CSDL
Database: `lab10`

Tài khoản ứng dụng:
- ADMIN: `admin@eaut.edu.vn` / `123456`
- STAFF: `staff@eaut.edu.vn` / `123456`
- USER: `user@eaut.edu.vn` / `123456`

Tài khoản MySQL dùng cho ứng dụng:
- User: `lab10user`
- Password: `123456`

Nếu bạn dùng đúng database script và đã tạo tài khoản MySQL theo hướng dẫn:
```sql
CREATE USER IF NOT EXISTS 'lab10user'@'localhost' IDENTIFIED BY '123456';
ALTER USER 'lab10user'@'localhost' IDENTIFIED BY '123456';
GRANT ALL PRIVILEGES ON lab10.* TO 'lab10user'@'localhost';
FLUSH PRIVILEGES;
```

## Chạy
1. Mở project bằng IntelliJ.
2. Maven Reload.
3. Kiểm tra Project SDK = JDK 26.
4. Chạy `database.sql` trong MySQL Workbench.
5. Kiểm tra `persistence.xml`:
   - database: `lab10`
   - user: `lab10user`
   - password: `123456`
6. Cấu hình Tomcat 10.1.x.
7. Deployment: `lab10-secured-app:war exploded`.
8. Context path có thể đặt `/lab10_secured_app`.
9. Run Tomcat.
10. Mở `http://localhost:8080/lab10_secured_app/`.

## Lưu ý
Mật khẩu ứng dụng được lưu plain text chỉ để phục vụ bài lab. Hệ thống thực tế phải dùng password hashing như Argon2/bcrypt/PBKDF2.
