package vn.edu.eaut.lab6.store;

import vn.edu.eaut.lab6.model.Student;
import java.util.ArrayList;
import java.util.List;

public class StudentStore {
    private static final List<Student> students = new ArrayList<>();

    static {
        students.add(new Student("SV001", "Nguyen Van An", "DCCNTT12", "an@example.com"));
        students.add(new Student("SV002", "Tran Thi Binh", "DCCNTT12", "binh@example.com"));
        students.add(new Student("SV003", "Le Van Cuong", "DCCNTT13", "cuong@example.com"));
        students.add(new Student("SV004", "Pham Thi Dung", "DCCNTT13", "dung@example.com"));
        students.add(new Student("SV005", "Hoang Van Em", "DCCNTT14", "em@example.com"));
    }

    public static synchronized List<Student> findAll() {
        return new ArrayList<>(students);
    }

    public static synchronized void add(Student student) {
        students.add(student);
    }

    public static synchronized void delete(String id) {
        students.removeIf(s -> s.getId().equals(id));
    }

    public static synchronized Student findById(String id) {
        return students.stream()
                .filter(s -> s.getId().equals(id))
                .findFirst().orElse(null);
    }

    public static synchronized void update(Student updated) {
        Student old = findById(updated.getId());
        if (old != null) {
            old.setName(updated.getName());
            old.setClassName(updated.getClassName());
            old.setEmail(updated.getEmail());
        }
    }

    public static synchronized List<Student> search(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) return findAll();
        String k = keyword.trim().toLowerCase();
        return students.stream()
                .filter(s -> s.getName().toLowerCase().contains(k))
                .toList();
    }
}
