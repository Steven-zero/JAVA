package vn.edu.eaut.lab8.bean;

import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;
import vn.edu.eaut.lab8.model.SinhVien;
import vn.edu.eaut.lab8.repository.SinhVienRepository;

import java.io.Serializable;
import java.util.List;
import java.util.stream.Collectors;

@Named("sinhVienBean")
@SessionScoped
public class SinhVienBean implements Serializable {
    private SinhVien sinhVien = new SinhVien();
    private final SinhVienRepository repo = new SinhVienRepository();
    private String keyword = "";

    public String save() {
        repo.add(sinhVien);
        message(FacesMessage.SEVERITY_INFO, "Thành công", "Đã thêm sinh viên.");
        sinhVien = new SinhVien();
        return "sinhvien-list?faces-redirect=true";
    }

    public String update() {
        repo.update(sinhVien);
        message(FacesMessage.SEVERITY_INFO, "Thành công", "Đã cập nhật sinh viên.");
        sinhVien = new SinhVien();
        return "sinhvien-list?faces-redirect=true";
    }

    public void delete(int id) {
        repo.delete(id);
        message(FacesMessage.SEVERITY_INFO, "Thành công", "Đã xóa sinh viên.");
    }

    public String edit(int id) {
        SinhVien found = repo.findById(id);
        if (found != null) {
            sinhVien = found.copy();
        }
        return "sinhvien-form?faces-redirect=true";
    }

    public List<SinhVien> getDsSinhVien() {
        String k = keyword == null ? "" : keyword.trim().toLowerCase();
        if (k.isEmpty()) return repo.findAll();
        return repo.findAll().stream()
                .filter(s -> s.getHoTen().toLowerCase().contains(k)
                        || s.getLop().toLowerCase().contains(k)
                        || s.getMaSinhVien().toLowerCase().contains(k))
                .collect(Collectors.toList());
    }

    public String getFormTitle() {
        return sinhVien.getId() == 0 ? "Thêm sinh viên" : "Sửa sinh viên";
    }

    public void reset() { sinhVien = new SinhVien(); }

    private void message(FacesMessage.Severity severity, String summary, String detail) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(severity, summary, detail));
    }

    public SinhVien getSinhVien() { return sinhVien; }
    public void setSinhVien(SinhVien sinhVien) { this.sinhVien = sinhVien; }
    public String getKeyword() { return keyword; }
    public void setKeyword(String keyword) { this.keyword = keyword; }
}
