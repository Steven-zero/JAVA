<%@ page contentType="text/html;charset=UTF-8" %>
<!doctype html><html><head><meta charset="UTF-8"><title>Lab 7</title>
<style>body{font-family:Arial;background:#f4f6f8;margin:40px}.box{max-width:800px;margin:auto;background:white;padding:30px;border-radius:12px}a{display:inline-block;margin:8px;padding:10px 16px;background:#2563eb;color:white;text-decoration:none;border-radius:6px}</style>
</head><body><div class="box"><h1>Lab 7 - CRUD MVC</h1>
<p>Servlet + JSP + JSTL + MVC đơn giản</p>
<a href="${pageContext.request.contextPath}/sinh-vien">Quản lý sinh viên</a>
<a href="${pageContext.request.contextPath}/login.jsp">Đăng nhập</a>
</div></body></html>