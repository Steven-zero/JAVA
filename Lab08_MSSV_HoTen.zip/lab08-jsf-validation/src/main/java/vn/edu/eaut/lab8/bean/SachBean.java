package vn.edu.eaut.lab8.bean;

import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;
import vn.edu.eaut.lab8.model.Sach;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Named("sachBean")
@SessionScoped
public class SachBean implements Serializable {
    private Sach sach = new Sach();
    private final List<Sach> dsSach = new ArrayList<>();

    public void save() {
        dsSach.add(sach);
        FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Thành công", "Đã thêm sách."));
        sach = new Sach();
    }
    public Sach getSach(){return sach;} public void setSach(Sach s){sach=s;}
    public List<Sach> getDsSach(){return dsSach;}
}
