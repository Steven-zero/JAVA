<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html><html lang="vi"><head><meta charset="UTF-8"><title>Sửa sinh viên</title>
<style>body{font-family:Arial;background:#f4f7fb}.box{width:600px;margin:40px auto;background:white;padding:30px;border-radius:12px}input{width:100%;padding:11px;margin:7px 0 15px;box-sizing:border-box}button{padding:11px 20px;background:#173b68;color:white;border:0;border-radius:6px}</style>
</head><body><div class="box"><h2>Cập nhật sinh viên</h2>
<form action="${pageContext.request.contextPath}/students/edit" method="post">
<label>Mã sinh viên (không sửa)</label><input name="id" value="${student.id}" readonly>
<label>Họ tên</label><input name="name" value="${student.name}" required>
<label>Lớp</label><input name="className" value="${student.className}" required>
<label>Email</label><input type="email" name="email" value="${student.email}" required>
<button>Cập nhật</button> <a href="${pageContext.request.contextPath}/students">Quay lại</a>
</form></div></body></html>
