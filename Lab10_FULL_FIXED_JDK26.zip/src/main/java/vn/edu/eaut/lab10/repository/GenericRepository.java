package vn.edu.eaut.lab10.repository;
import jakarta.persistence.*; import vn.edu.eaut.lab10.config.JPAUtil; import java.util.*;
public class GenericRepository<T> {
 private final Class<T> type;
 public GenericRepository(Class<T> type){this.type=type;}
 public List<T> findAll(){EntityManager em=JPAUtil.getEntityManagerFactory().createEntityManager();try{return em.createQuery("from "+type.getSimpleName(),type).getResultList();}finally{em.close();}}
 public T find(Integer id){EntityManager em=JPAUtil.getEntityManagerFactory().createEntityManager();try{return em.find(type,id);}finally{em.close();}}
 public void save(T x){EntityManager em=JPAUtil.getEntityManagerFactory().createEntityManager();EntityTransaction tx=em.getTransaction();try{tx.begin();em.persist(x);tx.commit();}catch(RuntimeException e){if(tx.isActive())tx.rollback();throw e;}finally{em.close();}}
 public void update(T x){EntityManager em=JPAUtil.getEntityManagerFactory().createEntityManager();EntityTransaction tx=em.getTransaction();try{tx.begin();em.merge(x);tx.commit();}catch(RuntimeException e){if(tx.isActive())tx.rollback();throw e;}finally{em.close();}}
 public void delete(Integer id){EntityManager em=JPAUtil.getEntityManagerFactory().createEntityManager();EntityTransaction tx=em.getTransaction();try{tx.begin();T x=em.find(type,id);if(x!=null)em.remove(x);tx.commit();}catch(RuntimeException e){if(tx.isActive())tx.rollback();throw e;}finally{em.close();}}
}