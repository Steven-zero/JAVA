package vn.edu.eaut.lab10.controller;
import jakarta.servlet.*; import jakarta.servlet.annotation.WebServlet; import jakarta.servlet.http.*; import java.io.*; import vn.edu.eaut.lab10.model.Product; import vn.edu.eaut.lab10.repository.GenericRepository;
@WebServlet("/products") public class ProductController extends HttpServlet {
 private final GenericRepository<Product> repo=new GenericRepository<>(Product.class);
 protected void doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException {
  String action=req.getParameter("action"); if("delete".equals(action)){repo.delete(Integer.valueOf(req.getParameter("id")));resp.sendRedirect(req.getContextPath()+"/products");return;}
  if("edit".equals(action)) req.setAttribute("item",repo.find(Integer.valueOf(req.getParameter("id"))));
  req.setAttribute("items",repo.findAll()); req.getRequestDispatcher("/products/index.jsp").forward(req,resp);
 }
 protected void doPost(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException {
  req.setCharacterEncoding("UTF-8"); try {
   String id=req.getParameter("id"); String name=req.getParameter("name");
String category=req.getParameter("category");
String quantity=req.getParameter("quantity");
String price=req.getParameter("price");
   Product obj;
   if(id==null||id.isBlank()) obj=new Product(); else obj=repo.find(Integer.valueOf(id));
   obj.setName(name);
obj.setCategory(category);
obj.setQuantity(Integer.valueOf(quantity));
obj.setPrice(Double.valueOf(price));
   if(id==null||id.isBlank())repo.save(obj);else repo.update(obj);
   resp.sendRedirect(req.getContextPath()+"/products");
  } catch(Exception e) {req.setAttribute("error","Dữ liệu không hợp lệ: "+e.getMessage());req.setAttribute("items",repo.findAll());req.getRequestDispatcher("/products/index.jsp").forward(req,resp);}
 }
}