package vn.edu.eaut.lab7.controller;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import vn.edu.eaut.lab7.model.SinhVien;
import vn.edu.eaut.lab7.repository.SinhVienRepository;
import java.io.IOException;

@WebServlet("/sinh-vien")
public class SinhVienController extends HttpServlet {
    private final SinhVienRepository repo = new SinhVienRepository();

    protected void doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{
        req.setCharacterEncoding("UTF-8");
        String action=req.getParameter("action");
        if("new".equals(action)){req.getRequestDispatcher("/views/sinhvien/form.jsp").forward(req,resp);return;}
        if("edit".equals(action)){req.setAttribute("sv",repo.findById(Integer.parseInt(req.getParameter("id"))));req.getRequestDispatcher("/views/sinhvien/form.jsp").forward(req,resp);return;}
        if("detail".equals(action)){req.setAttribute("sv",repo.findById(Integer.parseInt(req.getParameter("id"))));req.getRequestDispatcher("/views/sinhvien/detail.jsp").forward(req,resp);return;}
        if("delete".equals(action)){repo.delete(Integer.parseInt(req.getParameter("id")));resp.sendRedirect(req.getContextPath()+"/sinh-vien");return;}
        req.setAttribute("dsSinhVien",repo.search(req.getParameter("keyword")));
        req.getRequestDispatcher("/views/sinhvien/list.jsp").forward(req,resp);
    }

    protected void doPost(HttpServletRequest req,HttpServletResponse resp)throws IOException{
        req.setCharacterEncoding("UTF-8");
        String id=req.getParameter("id");
        String ma=req.getParameter("maSinhVien"), ten=req.getParameter("hoTen"), email=req.getParameter("email"), lop=req.getParameter("lop");
        if(ma==null||ma.isBlank()||ten==null||ten.isBlank()){
            resp.sendRedirect(req.getContextPath()+"/sinh-vien?action=new&error=required"); return;
        }
        SinhVien sv=new SinhVien(id==null||id.isBlank()?0:Integer.parseInt(id),ma,ten,email,lop);
        if(sv.getId()==0) repo.add(sv); else repo.update(sv);
        resp.sendRedirect(req.getContextPath()+"/sinh-vien");
    }
}