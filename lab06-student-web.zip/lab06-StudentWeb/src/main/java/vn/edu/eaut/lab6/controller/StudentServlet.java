package vn.edu.eaut.lab6.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import vn.edu.eaut.lab6.model.Student;
import vn.edu.eaut.lab6.store.StudentStore;
import java.io.IOException;

@WebServlet("/students")
public class StudentServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("delete".equals(action)) {
            StudentStore.delete(request.getParameter("id"));
            response.sendRedirect(request.getContextPath() + "/students");
            return;
        }
        if ("edit".equals(action)) {
            request.setAttribute("student", StudentStore.findById(request.getParameter("id")));
            request.getRequestDispatcher("/student-form.jsp").forward(request, response);
            return;
        }

        String keyword = request.getParameter("keyword");
        request.setAttribute("keyword", keyword == null ? "" : keyword);
        request.setAttribute("students", StudentStore.search(keyword));
        request.getRequestDispatcher("/student-list.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");
        String id = request.getParameter("id");
        String name = request.getParameter("name");
        String className = request.getParameter("className");
        String email = request.getParameter("email");

        if ("update".equals(action)) {
            StudentStore.update(new Student(id, name, className, email));
        } else {
            if (StudentStore.findById(id) == null) {
                StudentStore.add(new Student(id, name, className, email));
            }
        }
        response.sendRedirect(request.getContextPath() + "/students");
    }
}
