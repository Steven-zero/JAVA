package vn.edu.eaut.lab10.controller;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import vn.edu.eaut.lab10.model.*;
import vn.edu.eaut.lab10.repository.UserRepository;

@WebServlet("/admin/users")
public class AdminUserController extends HttpServlet {
    private final UserRepository repo = new UserRepository();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        if ("delete".equals(action)) {
            try {
                Integer id = Integer.valueOf(request.getParameter("id"));
                User current = (User) request.getSession().getAttribute("currentUser");

                if (current != null && current.getId().equals(id)) {
                    request.setAttribute("error", "Không thể tự xóa tài khoản đang đăng nhập.");
                } else {
                    repo.delete(id);
                    response.sendRedirect(request.getContextPath() + "/admin/users");
                    return;
                }
            } catch (Exception e) {
                request.setAttribute("error", "Không thể xóa tài khoản: " + e.getMessage());
            }
        }

        if ("edit".equals(action)) {
            try {
                request.setAttribute("item",
                        repo.find(Integer.valueOf(request.getParameter("id"))));
            } catch (Exception e) {
                request.setAttribute("error", "ID tài khoản không hợp lệ.");
            }
        }

        request.setAttribute("keyword", request.getParameter("keyword"));
        request.setAttribute("items",
                repo.findAllByEmail(request.getParameter("keyword")));

        request.getRequestDispatcher("/admin/users.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            request.setCharacterEncoding("UTF-8");

            String id = request.getParameter("id");
            String email = request.getParameter("email");
            String fullName = request.getParameter("fullName");
            String role = request.getParameter("role");
            String password = request.getParameter("password");

            if (email == null || email.isBlank() ||
                    fullName == null || fullName.isBlank() ||
                    role == null || role.isBlank()) {
                throw new IllegalArgumentException("Email, họ tên và role không được để trống.");
            }

            User u = id == null || id.isBlank()
                    ? new User()
                    : repo.find(Integer.valueOf(id));

            if (u == null) throw new IllegalArgumentException("Không tìm thấy tài khoản.");

            u.setEmail(email.trim());
            u.setFullName(fullName.trim());
            u.setRole(Role.valueOf(role));
            u.setActive("on".equals(request.getParameter("active")));

            if (id == null || id.isBlank()) {
                if (password == null || password.isBlank()) {
                    throw new IllegalArgumentException("Mật khẩu bắt buộc khi tạo tài khoản.");
                }
                u.setPassword(password);
                repo.save(u);
            } else {
                if (password != null && !password.isBlank()) {
                    u.setPassword(password);
                }
                repo.update(u);
            }

            response.sendRedirect(request.getContextPath() + "/admin/users");

        } catch (Exception e) {
            request.setAttribute("error", "Không thể lưu tài khoản: " + e.getMessage());
            request.setAttribute("items",
                    repo.findAllByEmail(request.getParameter("keyword")));
            request.getRequestDispatcher("/admin/users.jsp").forward(request, response);
        }
    }
}
