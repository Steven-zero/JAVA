package vn.edu.eaut.lab8.model;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import java.io.Serializable;
import java.math.BigDecimal;

public class Product implements Serializable {
    @NotBlank(message="Tên sản phẩm không được để trống")
    private String ten;
    @DecimalMin(value="0.01", message="Giá phải lớn hơn 0")
    private BigDecimal gia = BigDecimal.ZERO;
    @Min(value=0, message="Số lượng phải >= 0")
    private int soLuong;

    public Product() {}
    public String getTen(){return ten;} public void setTen(String v){ten=v;}
    public BigDecimal getGia(){return gia;} public void setGia(BigDecimal v){gia=v;}
    public int getSoLuong(){return soLuong;} public void setSoLuong(int v){soLuong=v;}
}
