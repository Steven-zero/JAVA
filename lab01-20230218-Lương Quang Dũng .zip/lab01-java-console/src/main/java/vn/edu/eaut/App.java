package vn.edu.eaut.lab1;

import java.util.Scanner;

public class App {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        int chon;

        do {

            System.out.println("\n========== LAB 1 ==========");
            System.out.println("1. Tinh tong so chan");
            System.out.println("2. Tinh tong nghich dao");
            System.out.println("3. Kiem tra so nguyen to");
            System.out.println("4. Kiem tra va phan loai tam giac");
            System.out.println("5. Hien thi day Fibonacci");
            System.out.println("0. Thoat");

            System.out.print("Nhap lua chon: ");
            chon = scanner.nextInt();

            switch (chon) {

                case 1:
                    System.out.print("Nhap n: ");
                    int n1 = scanner.nextInt();

                    System.out.println("Tong = " + So.tongChanDenN(n1));
                    break;

                case 2:
                    System.out.print("Nhap n: ");
                    int n2 = scanner.nextInt();

                    System.out.printf("Tong = %.4f\n", So.tongNghichDao(n2));
                    break;

                case 3:
                    System.out.print("Nhap n: ");
                    int n3 = scanner.nextInt();

                    if (So.laSoNguyenTo(n3))
                        System.out.println(n3 + " la so nguyen to.");
                    else
                        System.out.println(n3 + " khong phai la so nguyen to.");

                    break;

                case 4:
                    System.out.print("Nhap a: ");
                    double a = scanner.nextDouble();

                    System.out.print("Nhap b: ");
                    double b = scanner.nextDouble();

                    System.out.print("Nhap c: ");
                    double c = scanner.nextDouble();

                    System.out.println("Ket qua: " + So.loaiTamGiac(a, b, c));
                    break;

                case 5:
                    System.out.print("Nhap n: ");
                    int n5 = scanner.nextInt();

                    System.out.println("Day Fibonacci: " + So.dayFibonacci(n5));
                    break;

                case 0:
                    System.out.println("Ket thuc chuong trinh.");
                    break;

                default:
                    System.out.println("Lua chon khong hop le.");

            }

        } while (chon != 0);

        scanner.close();
    }
}