<%@ page contentType="text/html;charset=UTF-8" %>
<!doctype html><html><head><meta charset="UTF-8"><title>Chi tiết</title></head>
<body><h2>Chi tiết sinh viên</h2>
<p>ID: ${sv.id}</p><p>Mã sinh viên: ${sv.maSinhVien}</p><p>Họ tên: ${sv.hoTen}</p><p>Email: ${sv.email}</p><p>Lớp: ${sv.lop}</p>
<a href="${pageContext.request.contextPath}/sinh-vien">Quay lại</a></body></html>