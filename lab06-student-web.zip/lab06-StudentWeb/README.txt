LAB 6 - QUAN LY SINH VIEN

Công nghệ: Java 17, Maven, Jakarta Servlet 6, JSP, JSTL, Tomcat 10.x.

Tài khoản:
- Admin: admin / 123456
- User : user / 123456

Build:
mvn clean package

File WAR:
target/lab06-student-web.war

Deploy lên Tomcat:
copy file WAR vào thư mục webapps của Tomcat 10.x.

URL:
http://localhost:8080/lab06-student-web/

Chức năng:
1. Hello Servlet
2. Thêm sinh viên
3. Hiển thị danh sách bằng JSP + JSTL
4. Login + Session
5. AuthFilter + Listener
6. Tìm kiếm
7. Xóa
8. Cập nhật
9. Phân quyền Admin/User
10. Dashboard
11. Access Log Filter
12. Listener khởi tạo dữ liệu mẫu

Lưu ý:
Dữ liệu sinh viên đang lưu trong bộ nhớ (ArrayList), không dùng CSDL ở Lab 6.
