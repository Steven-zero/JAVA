package vn.edu.eaut.lab10.model;
import jakarta.persistence.*;
@Entity @Table(name="products")
public class Product {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Integer id;
 @Column(nullable=false,length=120) private String name;
 @Column(nullable=false,length=80) private String category;
 @Column(nullable=false) private Integer quantity;
 @Column(nullable=false) private Double price;
 public Product(){} public Integer getId(){return id;} public void setId(Integer v){id=v;} public String getName(){return name;} public void setName(String v){name=v;} public String getCategory(){return category;} public void setCategory(String v){category=v;} public Integer getQuantity(){return quantity;} public void setQuantity(Integer v){quantity=v;} public Double getPrice(){return price;} public void setPrice(Double v){price=v;}
}