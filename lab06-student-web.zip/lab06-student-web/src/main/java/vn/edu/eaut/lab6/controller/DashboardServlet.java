package vn.edu.eaut.lab6.controller;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import jakarta.servlet.ServletException;
import vn.edu.eaut.lab6.store.StudentStore;
import java.io.IOException;

@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setAttribute("students", StudentStore.findAll());
        request.setAttribute("total", StudentStore.findAll().size());
        request.getRequestDispatcher("/welcome.jsp").forward(request, response);
    }
}
