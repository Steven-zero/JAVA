<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!doctype html><html><head><meta charset="UTF-8"><title>Sinh viên</title>
<style>body{font-family:Arial;margin:30px;background:#f7f7f7}.box{background:white;padding:24px;border-radius:12px}table{width:100%;border-collapse:collapse;margin-top:15px}th,td{border:1px solid #ddd;padding:10px}th{background:#e5e7eb}a,button{padding:7px 10px;text-decoration:none}input{padding:8px}</style>
</head><body><div class="box"><h2>Danh sách sinh viên</h2>
<form method="get" action="${pageContext.request.contextPath}/sinh-vien"><input name="keyword" value="${param.keyword}" placeholder="Tìm mã, tên hoặc lớp"><button>Tìm</button></form>
<p><a href="${pageContext.request.contextPath}/">Trang chủ</a> | <a href="${pageContext.request.contextPath}/sinh-vien?action=new">+ Thêm sinh viên</a></p>
<table><tr><th>ID</th><th>Mã SV</th><th>Họ tên</th><th>Email</th><th>Lớp</th><th>Thao tác</th></tr>
<c:forEach var="sv" items="${dsSinhVien}"><tr>
<td>${sv.id}</td><td>${sv.maSinhVien}</td><td><a href="${pageContext.request.contextPath}/sinh-vien?action=detail&id=${sv.id}">${sv.hoTen}</a></td><td>${sv.email}</td><td>${sv.lop}</td>
<td><a href="${pageContext.request.contextPath}/sinh-vien?action=edit&id=${sv.id}">Sửa</a>
<a href="${pageContext.request.contextPath}/sinh-vien?action=delete&id=${sv.id}" onclick="return confirm('Bạn có chắc muốn xóa?')">Xóa</a></td>
</tr></c:forEach></table></div></body></html>