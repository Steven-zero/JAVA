package vn.edu.eaut.lab10.controller;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import vn.edu.eaut.lab10.model.User;
import vn.edu.eaut.lab10.repository.UserRepository;

@WebServlet("/user/profile")
public class ProfileController extends HttpServlet {
    private final UserRepository repo = new UserRepository();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/user/profile.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        User user = (User) request.getSession().getAttribute("currentUser");
        String name = request.getParameter("fullName");
        String email = request.getParameter("email");

        if (name == null || name.isBlank() || email == null || email.isBlank()) {
            request.setAttribute("error", "Họ tên và email không được để trống.");
            request.getRequestDispatcher("/user/profile.jsp").forward(request, response);
            return;
        }

        email = email.trim();

        User existing = repo.findByEmail(email);
        if (existing != null && !existing.getId().equals(user.getId())) {
            request.setAttribute("error", "Email đã được sử dụng bởi tài khoản khác.");
            request.getRequestDispatcher("/user/profile.jsp").forward(request, response);
            return;
        }

        try {
            user.setFullName(name.trim());
            user.setEmail(email);
            repo.update(user);

            request.getSession().setAttribute("currentUser", user);
            request.setAttribute("success", "Cập nhật hồ sơ thành công.");
        } catch (Exception e) {
            request.setAttribute("error", "Không thể cập nhật hồ sơ: " + e.getMessage());
        }

        request.getRequestDispatcher("/user/profile.jsp").forward(request, response);
    }
}
