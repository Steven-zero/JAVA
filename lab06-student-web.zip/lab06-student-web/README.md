# LAB 6 - Xây dựng ứng dụng Web quản lý sinh viên

## Công nghệ
- JDK 17
- Maven
- Apache Tomcat 10.x
- Jakarta Servlet 6.0
- JSP + JSTL
- MVC cơ bản

## Tài khoản
- Admin: `admin` / `123456`
- User: `user` / `123456`

## Chạy bằng IntelliJ
1. Mở thư mục project.
2. Maven Reload.
3. Cấu hình Tomcat 10.x.
4. Deploy artifact `lab06-student-web:war exploded`.
5. Chạy Tomcat.
6. Mở: http://localhost:8080/lab06-student-web/

## Chạy bằng Maven
```bash
mvn clean package
```
Sau đó lấy file:
`target/lab06-student-web.war`
copy vào thư mục `webapps` của Tomcat và khởi động Tomcat.

## Chức năng
- Bài 1: /hello
- Bài 2-3: thêm và hiển thị sinh viên
- Bài 4: đăng nhập + Session
- Bài 5: AuthFilter + Listener
- Bài 6: tìm kiếm theo họ tên
- Bài 7: xóa
- Bài 8: cập nhật
- Bài 9: phân quyền Admin/User
- Bài 10: Dashboard
- Bài 11: AccessLogFilter
- Bài 12: Listener khởi tạo 5 sinh viên mẫu

Dữ liệu hiện lưu trong RAM, chưa dùng CSDL.
