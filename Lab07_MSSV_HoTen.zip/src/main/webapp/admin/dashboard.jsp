<%@ page contentType="text/html;charset=UTF-8" %>
<!doctype html><html><head><meta charset="UTF-8"><title>Admin</title></head>
<body><h2>Khu vực quản trị</h2><p>Xin chào, ${sessionScope.username}!</p>
<p>URL này được bảo vệ bởi LoginFilter.</p><a href="${pageContext.request.contextPath}/login">Đăng xuất</a></body></html>