package vn.edu.eaut.lab5.dal;

import vn.edu.eaut.lab5.config.DBHelper;
import vn.edu.eaut.lab5.model.SanPham;
import java.sql.*;
import java.util.*;

public class SanPhamDAL {
    private SanPham map(ResultSet rs) throws SQLException {
        return new SanPham(rs.getInt("ma_sp"), rs.getString("ten_sp"),
                rs.getBigDecimal("don_gia"), rs.getInt("so_luong"));
    }
    public List<SanPham> findAll() throws SQLException {
        List<SanPham> list=new ArrayList<>();
        String sql="SELECT * FROM san_pham ORDER BY ma_sp";
        try(Connection c=DBHelper.getConnection(); PreparedStatement p=c.prepareStatement(sql); ResultSet r=p.executeQuery()){
            while(r.next()) list.add(map(r));
        }
        return list;
    }
    public boolean insert(SanPham sp) throws SQLException {
        String sql="INSERT INTO san_pham(ten_sp,don_gia,so_luong) VALUES(?,?,?)";
        try(Connection c=DBHelper.getConnection(); PreparedStatement p=c.prepareStatement(sql)){
            p.setString(1,sp.getTenSp()); p.setBigDecimal(2,sp.getDonGia()); p.setInt(3,sp.getSoLuong());
            return p.executeUpdate()>0;
        }
    }
    public boolean update(SanPham sp) throws SQLException {
        String sql="UPDATE san_pham SET ten_sp=?,don_gia=?,so_luong=? WHERE ma_sp=?";
        try(Connection c=DBHelper.getConnection(); PreparedStatement p=c.prepareStatement(sql)){
            p.setString(1,sp.getTenSp()); p.setBigDecimal(2,sp.getDonGia()); p.setInt(3,sp.getSoLuong()); p.setInt(4,sp.getMaSp());
            return p.executeUpdate()>0;
        }
    }
    public boolean delete(int maSp) throws SQLException {
        try(Connection c=DBHelper.getConnection(); PreparedStatement p=c.prepareStatement("DELETE FROM san_pham WHERE ma_sp=?")){
            p.setInt(1,maSp); return p.executeUpdate()>0;
        }
    }
    public List<SanPham> searchByName(String k) throws SQLException {
        List<SanPham> list=new ArrayList<>();
        try(Connection c=DBHelper.getConnection(); PreparedStatement p=c.prepareStatement(
                "SELECT * FROM san_pham WHERE ten_sp LIKE ? ORDER BY ma_sp")){
            p.setString(1,"%"+k+"%");
            try(ResultSet r=p.executeQuery()){while(r.next()) list.add(map(r));}
        }
        return list;
    }
}
